import pathlib,subprocess,fcntl
root=pathlib.Path(__file__).resolve().parent
locks=[]
for name in ['prindal-addition-encoder-benchmark','bare-spin-benchmark','hypercat-benchmark']:
 f=open('/tmp/'+name+'.lock','w');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
for mode in ['wide2','avx2','portable']:
 out=subprocess.check_output(['taskset','-c','2',str(root/('directions-'+mode)),'2097152',('5' if mode=='portable' else '15'),'1'],text=True)
 (root/'results'/('backend-'+mode+'.csv')).write_text(out);print(mode,out,flush=True)
