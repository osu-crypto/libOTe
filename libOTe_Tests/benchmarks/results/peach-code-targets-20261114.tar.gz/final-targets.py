import pathlib,subprocess,fcntl,csv,statistics,json,hashlib,tarfile
root=pathlib.Path(__file__).resolve().parent
locks=[]
for name in ['prindal-addition-encoder-benchmark','bare-spin-benchmark','hypercat-benchmark']:
 f=open('/tmp/'+name+'.lock','w');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
result=root/'results';result.mkdir(exist_ok=True)
rows=[]
for seed in range(1,7):
 for tag in (['old','new'] if seed%2 else ['new','old']):
  exe=root/'directions-wide4' if tag=='new' else root.parent/'directions/directions-wide4'
  text=subprocess.check_output(['taskset','-c','2',str(exe),'2097152','31',str(seed)],text=True)
  (result/f'{tag}-{seed}.csv').write_text(text)
  for row in csv.DictReader(text.splitlines()):row['version']=tag;rows.append(row)
  print(tag,seed,text.strip().splitlines()[1:3],flush=True)
summary={}
for tag in ['old','new']:
 summary[tag]={}
 for code in ['gf128_rm','gf128_q256','gf128_rs']:
  subset=[r for r in rows if r['version']==tag and r['code']==code]
  summary[tag][code]={}
  for direction in ['forward_ms','transpose_ms']:
   vals=[float(r[direction]) for r in subset];summary[tag][code][direction]={'median':statistics.median(vals),'min':min(vals),'max':max(vals)}
for seed in range(1,7):
 for code in ['gf128_rm','gf128_q256','gf128_rs']:
  vals=[r['checksum'] for r in rows if r['seed']==str(seed) and r['code']==code]
  assert len(vals)==2 and vals[0]==vals[1],(seed,code,vals)
(result/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
