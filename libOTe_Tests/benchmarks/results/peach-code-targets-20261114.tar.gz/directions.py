import pathlib, subprocess, sys, fcntl
root=pathlib.Path(__file__).resolve().parent
base=root.parent
mode=sys.argv[1]
flags=[]
if mode=='wide4':flags=['-march=native']
elif mode=='wide2':flags=['-maes','-mpclmul','-msse4.1','-mavx2','-mvpclmulqdq']
elif mode=='avx2':flags=['-maes','-mpclmul','-msse4.1','-mavx2']
elif mode=='arm':flags=['-march=armv8-a+crypto']
sources=[root/'libOTe_Tests/benchmarks/ChosenBaaDirections.cpp']+[base/'cryptoTools/cryptoTools'/f for f in ['Crypto/AES.cpp','Crypto/PRNG.cpp','Common/block.cpp','Common/Log.cpp']]
exe=root/('directions-'+mode)
if sys.argv[2]=='build':
    subprocess.run(['c++','-O3','-DNDEBUG','-std=c++20',*flags,'-I'+str(base/'build'/mode),'-I'+str(root),'-I'+str(base),'-I'+str(base/'cryptoTools'),*map(str,sources),'-pthread','-o',str(exe)],check=True)
else:
    locks=[]
    for name in ['prindal-addition-encoder-benchmark','bare-spin-benchmark','hypercat-benchmark']:
        f=open('/tmp/'+name+'.lock','w');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
    subprocess.run(([] if mode in ['arm','portable'] else ['taskset','-c','2'])+[str(exe),*sys.argv[2:]],check=True)
