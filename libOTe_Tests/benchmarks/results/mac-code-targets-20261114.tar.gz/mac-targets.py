import pathlib,subprocess,fcntl
root=pathlib.Path(__file__).resolve().parent
locks=[]
for name in ['prindal-addition-encoder-benchmark','bare-spin-benchmark','hypercat-benchmark']:
 f=open('/tmp/'+name+'.lock','w');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
result=root/'results';result.mkdir(exist_ok=True)
for seed in [1,2]:
 for tag in ['old','new']:
  exe=root/'directions-arm' if tag=='new' else root.parent/'directions/directions-arm'
  output=subprocess.check_output([str(exe),'2097152','15',str(seed)],text=True)
  (result/f'mac-{tag}-{seed}.csv').write_text(output);print(tag,seed,output,flush=True)
