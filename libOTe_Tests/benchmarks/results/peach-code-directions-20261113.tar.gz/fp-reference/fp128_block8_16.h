#pragma once
#include "fp128_block4_8.h"

namespace fp128 {
// Newton coefficients -> evaluations at 0,...,14, followed by the leading
// Newton coefficient. Exactly 77 additions. The largest coefficient sum is
// sum_{j=0}^7 binom(14,j)=9908, so unreduced base-2^43 limbs stay below 2^57.
template<unsigned T> inline void newton8_steps(Batch43 (&v)[8],Batch43 (&out)[16]) {
    constexpr unsigned count=(15-T<7)?15-T:7;
    #pragma GCC unroll 7
    for(unsigned j=0;j<count;++j)v[j]=batch_add(v[j],v[j+1]);
    out[T]=v[0];
    if constexpr(T<14)newton8_steps<T+1>(v,out);
}
inline void block8_16_batch8(const F* __restrict input,F* __restrict output) {
    Batch43 v[8];
    #pragma GCC unroll 2
    for(unsigned c=0;c<8;c+=4) {
        __m512i a,b,d,e,f,g,h,j;
        transpose128(_mm512_loadu_si512(input+c),_mm512_loadu_si512(input+8+c),
                     _mm512_loadu_si512(input+16+c),_mm512_loadu_si512(input+24+c),a,b,d,e);
        transpose128(_mm512_loadu_si512(input+32+c),_mm512_loadu_si512(input+40+c),
                     _mm512_loadu_si512(input+48+c),_mm512_loadu_si512(input+56+c),f,g,h,j);
        v[c]=batch_unpack(a,f);v[c+1]=batch_unpack(b,g);v[c+2]=batch_unpack(d,h);v[c+3]=batch_unpack(e,j);
    }
    // Keep reductions out of the recurrence: its 24 vector state registers
    // otherwise compete with reduction temporaries. Both fixed tiles stay
    // in L1, and each output is still reduced exactly once.
    Batch43 raw[16];raw[0]=v[0];raw[15]=v[7];newton8_steps<1>(v,raw);
    BatchPair values[16];
    #pragma GCC unroll 16
    for(unsigned j=0;j<16;++j)values[j]=batch_reduce(raw[j]);
    #pragma GCC unroll 2
    for(unsigned group=0;group<2;++group) {
        const __m512i indices=group?_mm512_setr_epi64(4,12,5,13,6,14,7,15):_mm512_setr_epi64(0,8,1,9,2,10,3,11);
        #pragma GCC unroll 4
        for(unsigned c=0;c<16;c+=4) {
            const __m512i a=_mm512_permutex2var_epi64(values[c].low,indices,values[c].high);
            const __m512i b=_mm512_permutex2var_epi64(values[c+1].low,indices,values[c+1].high);
            const __m512i d=_mm512_permutex2var_epi64(values[c+2].low,indices,values[c+2].high);
            const __m512i e=_mm512_permutex2var_epi64(values[c+3].low,indices,values[c+3].high);
            __m512i r0,r1,r2,r3;transpose128(a,b,d,e,r0,r1,r2,r3);
            F* dest=output+group*64+c;
            _mm512_storeu_si512(dest,r0);_mm512_storeu_si512(dest+16,r1);
            _mm512_storeu_si512(dest+32,r2);_mm512_storeu_si512(dest+48,r3);
        }
    }
}
inline void encode_block8_16(const F* __restrict input,F* __restrict output,size_t k) {
    size_t i=0;
    for(;i+64<=k;i+=64)block8_16_batch8(input+i,output+2*i);
    for(;i<k;i+=8) {
        Lazy128 v[8];
        #pragma GCC unroll 8
        for(unsigned j=0;j<8;++j)v[j]={input[i+j],0};
        output[2*i]=input[i];output[2*i+15]=input[i+7];
        #pragma GCC unroll 14
        for(unsigned t=1;t<15;++t) {
            #pragma GCC unroll 7
            for(unsigned j=0;j<7;++j)if(j<15-t)v[j]=lazy_add(v[j],v[j+1]);
            output[2*i+t]=lazy_reduce(v[0]);
        }
    }
}
}
