#pragma once
#include <cstdint>
#include <immintrin.h>

namespace fp128 {
using F=unsigned __int128;
constexpr F modulus=F(-1)-158;
inline F add(F a,F b) {
    F s=a+b;s+=F(159)&(F(0)-F(s<a));
    return s-(modulus&(F(0)-F(s>=modulus)));
}
inline F sub(F a,F b) {
    F d=a-b;return d-(F(159)&(F(0)-F(a<b)));
}
struct Wide {F low,high;};
inline Wide product(F a,F b) {
    const uint64_t a0=a,a1=a>>64,b0=b,b1=b>>64;
    const F p00=F(a0)*b0,p01=F(a0)*b1,p10=F(a1)*b0,p11=F(a1)*b1;
    const F middle=(p00>>64)+uint64_t(p01)+F(uint64_t(p10));
    return {(middle<<64)|uint64_t(p00),p11+(p01>>64)+(p10>>64)+(middle>>64)};
}
inline Wide product_bmi2(F a,F b) {
    unsigned long long h00,h01,h10,h11;
    const auto l00=_mulx_u64(uint64_t(a),uint64_t(b),&h00);
    const auto l01=_mulx_u64(uint64_t(a),uint64_t(b>>64),&h01);
    const auto l10=_mulx_u64(uint64_t(a>>64),uint64_t(b),&h10);
    const auto l11=_mulx_u64(uint64_t(a>>64),uint64_t(b>>64),&h11);
    unsigned long long middle;
    unsigned c0=_addcarry_u64(0,h00,l01,&middle);
    unsigned c1=_addcarry_u64(0,middle,l10,&middle);
    return {(F(middle)<<64)|l00,((F(h11)<<64)|l11)+h01+F(h10)+c0+c1};
}
inline F reduce(Wide t) {
    // Fold 2^128 = 159 (mod p), then fold the at-most-eight-bit excess.
    const F lo=F(uint64_t(t.high))*159+uint64_t(t.low);
    const F hi=F(uint64_t(t.high>>64))*159+uint64_t(t.low>>64)+(lo>>64);
    const F folded=(F(uint64_t(hi))<<64)|uint64_t(lo);
    return add(folded,(hi>>64)*159);
}
inline F mul(F a,F b) {return reduce(product(a,b));}
inline F mul_bmi2(F a,F b) {return reduce(product_bmi2(a,b));}
constexpr uint64_t inverse159() {
    uint64_t x=1;
    for(int i=0;i<6;++i) x*=2-159*x;
    return x;
}
inline F montgomery(F a,F b) {
    // Two-word REDC; returns a*b*2^-128 mod p. Inputs canonical Montgomery
    // residues; setup conversion is x -> 159*x mod p.
    const auto wide=product(a,b);
    uint64_t t[5]={uint64_t(wide.low),uint64_t(wide.low>>64),
                   uint64_t(wide.high),uint64_t(wide.high>>64),0};
    #pragma GCC unroll 2
    for(int i=0;i<2;++i) {
        const uint64_t m=t[i]*inverse159();
        F s=F(m)*uint64_t(modulus)+t[i];
        F u=F(m)*UINT64_MAX+t[i+1]+(s>>64);
        t[i+1]=uint64_t(u);
        F v=F(t[i+2])+(u>>64);t[i+2]=uint64_t(v);
        F w=F(t[i+3])+(v>>64);t[i+3]=uint64_t(w);
        if(i==0) t[4]+=uint64_t(w>>64);
    }
    return add((F(t[3])<<64)|t[2],F(t[4])*159);
}
inline F pow(F a,F exponent) {
    F out=1;
    while(exponent) {if(exponent&1) out=mul(out,a);a=mul(a,a);exponent>>=1;}
    return out;
}
inline F inverse(F a) {return pow(a,modulus-2);}
}
