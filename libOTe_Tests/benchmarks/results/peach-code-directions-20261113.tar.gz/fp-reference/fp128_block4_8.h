#pragma once
#include "fp128_mul.h"

namespace fp128 {
inline void block4_8_reference(const F* __restrict x,F* __restrict y) {
    F a=x[0],b=x[1],c=x[2];const F d=x[3];y[0]=a;y[7]=d;
    a=add(a,b);b=add(b,c);c=add(c,d);y[1]=a;
    a=add(a,b);b=add(b,c);c=add(c,d);y[2]=a;
    a=add(a,b);b=add(b,c);c=add(c,d);y[3]=a;
    a=add(a,b);b=add(b,c);c=add(c,d);y[4]=a;
    a=add(a,b);b=add(b,c);y[5]=a;
    a=add(a,b);y[6]=a;
}

struct Lazy128 {
    F low;uint64_t high;
};
inline Lazy128 lazy_add(Lazy128 a,Lazy128 b) {
    F low=a.low+b.low;
    return {low,a.high+b.high+uint64_t(low<a.low)};
}
inline F lazy_reduce(Lazy128 x) {return add(x.low,F(x.high)*159);}
inline void block4_8_lazy(const F* __restrict x,F* __restrict y) {
    Lazy128 a{x[0],0},b{x[1],0},c{x[2],0};const Lazy128 d{x[3],0};
    y[0]=a.low;y[7]=d.low;
    a=lazy_add(a,b);b=lazy_add(b,c);c=lazy_add(c,d);y[1]=lazy_reduce(a);
    a=lazy_add(a,b);b=lazy_add(b,c);c=lazy_add(c,d);y[2]=lazy_reduce(a);
    a=lazy_add(a,b);b=lazy_add(b,c);c=lazy_add(c,d);y[3]=lazy_reduce(a);
    a=lazy_add(a,b);b=lazy_add(b,c);c=lazy_add(c,d);y[4]=lazy_reduce(a);
    a=lazy_add(a,b);b=lazy_add(b,c);y[5]=lazy_reduce(a);
    a=lazy_add(a,b);y[6]=lazy_reduce(a);
}

// Eight independent fields in three base-2^43 limbs. Every unreduced local
// form has nonnegative coefficient sum<=42, so each limb stays below2^49.
// Addition needs no carry propagation until an output is stored.
struct Batch43 {__m512i a,b,c;};
inline Batch43 batch_add(Batch43 x,Batch43 y) {
    return {_mm512_add_epi64(x.a,y.a),_mm512_add_epi64(x.b,y.b),_mm512_add_epi64(x.c,y.c)};
}
inline Batch43 batch_load(const F* input,unsigned column) {
    const __m512i indices=_mm512_setr_epi64(0,8,16,24,32,40,48,56);
    const uint64_t* base=reinterpret_cast<const uint64_t*>(input)+2*column;
    const __m512i lo=_mm512_i64gather_epi64(indices,base,8);
    const __m512i hi=_mm512_i64gather_epi64(indices,base+1,8);
    const __m512i mask=_mm512_set1_epi64((uint64_t(1)<<43)-1);
    return {_mm512_and_si512(lo,mask),
            _mm512_and_si512(_mm512_or_si512(_mm512_srli_epi64(lo,43),_mm512_slli_epi64(hi,21)),mask),
            _mm512_srli_epi64(hi,22)};
}
struct BatchPair {__m512i low,high;};
inline BatchPair batch_reduce(Batch43 x) {
    const __m512i mask43=_mm512_set1_epi64((uint64_t(1)<<43)-1);
    const __m512i mask42=_mm512_set1_epi64((uint64_t(1)<<42)-1);
    const __m512i ones=_mm512_set1_epi64(1),allones=_mm512_set1_epi64(-1);
    const __m512i c159=_mm512_set1_epi64(159);
    x.b=_mm512_add_epi64(x.b,_mm512_srli_epi64(x.a,43));
    x.c=_mm512_add_epi64(x.c,_mm512_srli_epi64(x.b,43));
    x.a=_mm512_and_si512(x.a,mask43);x.b=_mm512_and_si512(x.b,mask43);
    const __m512i excess=_mm512_srli_epi64(x.c,42);
    x.c=_mm512_and_si512(x.c,mask42);
    const __m512i lo=_mm512_or_si512(x.a,_mm512_slli_epi64(x.b,43));
    const __m512i hi=_mm512_or_si512(_mm512_srli_epi64(x.b,21),_mm512_slli_epi64(x.c,22));
    const __m512i correction=_mm512_sub_epi64(
        _mm512_add_epi64(_mm512_slli_epi64(excess,7),_mm512_slli_epi64(excess,5)),excess);
    __m512i outlo=_mm512_add_epi64(lo,correction);
    const __mmask8 carry=_mm512_cmplt_epu64_mask(outlo,lo);
    __m512i outhi=_mm512_mask_add_epi64(hi,carry,hi,ones);
    const __mmask8 overflow=carry&_mm512_cmpeq_epi64_mask(hi,allones);
    const __mmask8 ge_p=_mm512_cmpeq_epi64_mask(outhi,allones)&
        _mm512_cmpge_epu64_mask(outlo,_mm512_set1_epi64(uint64_t(-159)));
    outlo=_mm512_mask_add_epi64(outlo,overflow|ge_p,outlo,c159);
    outhi=_mm512_mask_mov_epi64(outhi,ge_p,_mm512_setzero_si512());
    return {outlo,outhi};
}
inline void batch_store(F* output,unsigned column,Batch43 x) {
    const BatchPair reduced=batch_reduce(x);
    const __m512i indices=_mm512_setr_epi64(0,16,32,48,64,80,96,112);
    uint64_t* base=reinterpret_cast<uint64_t*>(output)+2*column;
    _mm512_i64scatter_epi64(base,indices,reduced.low,8);
    _mm512_i64scatter_epi64(base+1,indices,reduced.high,8);
}
inline void block4_8_batch8(const F* __restrict x,F* __restrict y) {
    Batch43 a=batch_load(x,0),b=batch_load(x,1),c=batch_load(x,2);const Batch43 d=batch_load(x,3);
    batch_store(y,0,a);batch_store(y,7,d);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);batch_store(y,1,a);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);batch_store(y,2,a);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);batch_store(y,3,a);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);batch_store(y,4,a);
    a=batch_add(a,b);b=batch_add(b,c);batch_store(y,5,a);
    a=batch_add(a,b);batch_store(y,6,a);
}

inline void transpose128(__m512i a,__m512i b,__m512i c,__m512i d,
                         __m512i& r0,__m512i& r1,__m512i& r2,__m512i& r3) {
    const __m512i t0=_mm512_shuffle_i64x2(a,b,0x44),t1=_mm512_shuffle_i64x2(a,b,0xee);
    const __m512i t2=_mm512_shuffle_i64x2(c,d,0x44),t3=_mm512_shuffle_i64x2(c,d,0xee);
    r0=_mm512_shuffle_i64x2(t0,t2,0x88);r1=_mm512_shuffle_i64x2(t0,t2,0xdd);
    r2=_mm512_shuffle_i64x2(t1,t3,0x88);r3=_mm512_shuffle_i64x2(t1,t3,0xdd);
}
inline Batch43 batch_unpack(__m512i first,__m512i second) {
    const __m512i lo=_mm512_permutex2var_epi64(first,_mm512_setr_epi64(0,2,4,6,8,10,12,14),second);
    const __m512i hi=_mm512_permutex2var_epi64(first,_mm512_setr_epi64(1,3,5,7,9,11,13,15),second);
    const __m512i mask=_mm512_set1_epi64((uint64_t(1)<<43)-1);
    return {_mm512_and_si512(lo,mask),
            _mm512_and_si512(_mm512_or_si512(_mm512_srli_epi64(lo,43),_mm512_slli_epi64(hi,21)),mask),
            _mm512_srli_epi64(hi,22)};
}
inline void block4_8_batch8_contiguous(const F* __restrict input,F* __restrict output) {
    __m512i a0,b0,c0,d0,a1,b1,c1,d1;
    transpose128(_mm512_loadu_si512(input),_mm512_loadu_si512(input+4),
                 _mm512_loadu_si512(input+8),_mm512_loadu_si512(input+12),a0,b0,c0,d0);
    transpose128(_mm512_loadu_si512(input+16),_mm512_loadu_si512(input+20),
                 _mm512_loadu_si512(input+24),_mm512_loadu_si512(input+28),a1,b1,c1,d1);
    Batch43 a=batch_unpack(a0,a1),b=batch_unpack(b0,b1),c=batch_unpack(c0,c1);
    const Batch43 d=batch_unpack(d0,d1);
    // Fixed1KiB local transpose tile. No heap allocation; each result is
    // reduced once and written back in exactly the original codeword order.
    BatchPair values[8];values[0]=batch_reduce(a);values[7]=batch_reduce(d);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);values[1]=batch_reduce(a);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);values[2]=batch_reduce(a);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);values[3]=batch_reduce(a);
    a=batch_add(a,b);b=batch_add(b,c);c=batch_add(c,d);values[4]=batch_reduce(a);
    a=batch_add(a,b);b=batch_add(b,c);values[5]=batch_reduce(a);
    a=batch_add(a,b);values[6]=batch_reduce(a);
    #pragma GCC unroll 2
    for(unsigned group=0;group<2;++group) {
        const __m512i indices=group?_mm512_setr_epi64(4,12,5,13,6,14,7,15):
                                      _mm512_setr_epi64(0,8,1,9,2,10,3,11);
        #pragma GCC unroll 2
        for(unsigned column=0;column<8;column+=4) {
            const __m512i v0=_mm512_permutex2var_epi64(values[column].low,indices,values[column].high);
            const __m512i v1=_mm512_permutex2var_epi64(values[column+1].low,indices,values[column+1].high);
            const __m512i v2=_mm512_permutex2var_epi64(values[column+2].low,indices,values[column+2].high);
            const __m512i v3=_mm512_permutex2var_epi64(values[column+3].low,indices,values[column+3].high);
            __m512i r0,r1,r2,r3;transpose128(v0,v1,v2,v3,r0,r1,r2,r3);
            F* dest=output+group*32+column;
            _mm512_storeu_si512(dest,r0);_mm512_storeu_si512(dest+8,r1);
            _mm512_storeu_si512(dest+16,r2);_mm512_storeu_si512(dest+24,r3);
        }
    }
}

enum class LocalKernel { baseline,lazy,avx512,contiguous };
template<LocalKernel Kernel> inline void encode_block4_8(const F* __restrict input,F* __restrict output,size_t k) {
    size_t i=0;
    if constexpr(Kernel==LocalKernel::avx512 || Kernel==LocalKernel::contiguous) {
        for(;i+31<k;i+=32) {
            if constexpr(Kernel==LocalKernel::avx512)block4_8_batch8(input+i,output+2*i);
            else block4_8_batch8_contiguous(input+i,output+2*i);
        }
    }
    for(;i<k;i+=4) {
        if constexpr(Kernel==LocalKernel::baseline) block4_8_reference(input+i,output+2*i);
        else block4_8_lazy(input+i,output+2*i);
    }
}
}
