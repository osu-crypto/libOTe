#pragma once
#include "fp128_convolution_alphabet.h"

namespace fp128 {
using CertifiedTwo=ConvolutionAlphabet<2048,11>;
struct CertifiedFour {
    struct Word {uint64_t first=0,second=0;};
    static_assert(sizeof(Word)==16);
    static uint32_t index(Word p){return uint32_t(p.first&conv_index_mask);}
    static unsigned a(Word p){return unsigned((p.first>>21)&65535)+1;}
    static unsigned b(Word p){return unsigned((p.first>>37)&65535)+1;}
    static unsigned c(Word p){return unsigned(p.second&65535)+1;}
    static unsigned d(Word p){return unsigned((p.second>>16)&65535)+1;}
    static Word pack(uint32_t i,unsigned a,unsigned b,unsigned c,unsigned d) {
        return {uint64_t(i)|(uint64_t(a-1)<<21)|(uint64_t(b-1)<<37),uint64_t(c-1)|(uint64_t(d-1)<<16)};
    }
};
inline ConvRaw certified_pair_raw(F x,unsigned a,F y,unsigned b) {
    // Each limb sum is <2^82 for coefficients <=65536. Exact 192-bit
    // products are combined before one field reduction, with no overflow.
    const F lo=F(uint64_t(x))*a+F(uint64_t(y))*b;
    const F hi=F(uint64_t(x>>64))*a+F(uint64_t(y>>64))*b+(lo>>64);
    return {(hi<<64)|uint64_t(lo),uint64_t(hi>>64)};
}
template<bool TwoFolds> inline F certified_madd4(F s0,F s1,F s2,F s3,unsigned a,unsigned b,unsigned c,unsigned d,__m128i input) {
    if constexpr(TwoFolds) {
        const F first=conv_madd_mulx(s0,a,s1,b,input);
        return conv_madd_mulx(s2,c,s3,d,_mm_loadu_si128(reinterpret_cast<const __m128i*>(&first)));
    } else {
        F gathered;_mm_storeu_si128(reinterpret_cast<__m128i*>(&gathered),input);
        // fold_small_asm's reduction also holds here: correction+159 <2^64.
        return sum_raw_asm(gathered,certified_pair_raw(s0,a,s1,b),certified_pair_raw(s2,c,s3,d));
    }
}
// Same batched gather, explicit unrolling and prefetch structure as the
// established two-tap kernel. Canonical disjoint buffers; padded metadata.
template<bool TwoFolds=false,unsigned PF=256,unsigned U=4> inline void certified_scan4(
        const F* __restrict src,F* __restrict dst,const CertifiedFour::Word* __restrict p,size_t n) {
    using A=CertifiedFour;F s0=0,s1=0,s2=0,s3=0;size_t i=0;
    for(;i+U<=n;i+=U) {
        __m128i gathered[U];A::Word meta[U];
        #pragma GCC unroll 16
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+A::index(p[i+j+PF]),0,1);
            meta[j]=p[i+j];gathered[j]=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+A::index(meta[j])));
        }
        #pragma GCC unroll 16
        for(unsigned j=0;j<U;++j) {
            const F out=certified_madd4<TwoFolds>(s0,s1,s2,s3,A::a(meta[j]),A::b(meta[j]),A::c(meta[j]),A::d(meta[j]),gathered[j]);
            s3=s2;s2=s1;s1=s0;s0=out;dst[i+j]=out;
        }
    }
    for(;i<n;++i) {
        const auto m=p[i];const auto input=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+A::index(m)));
        const F out=certified_madd4<TwoFolds>(s0,s1,s2,s3,A::a(m),A::b(m),A::c(m),A::d(m),input);
        s3=s2;s2=s1;s1=s0;s0=out;dst[i]=out;
    }
}
}
