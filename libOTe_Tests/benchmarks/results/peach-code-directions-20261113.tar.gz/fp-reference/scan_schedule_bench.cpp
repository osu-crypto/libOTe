#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main imported_encoder_main
#include "encoder_bench.cpp"
#undef main
#pragma GCC diagnostic pop
#include "fp128_small.h"
#include "fp128_block4_8.h"
#include "fp128_scan_schedule.h"

using BlockKernel=fp128::LocalKernel;
constexpr uint32_t MASK21=(1u<<21)-1;
const char* local_name(BlockKernel k) {
    if(k==BlockKernel::baseline)return "baseline";
    if(k==BlockKernel::lazy)return "lazy_scalar";
    if(k==BlockKernel::avx512)return "avx512_limb43";
    return "avx512_contiguous";
}

// Same packed metadata, setup stream, unrolled gather loop and fused positive
// scan as small_scan_bench.cpp; only scan scheduling/arithmetic varies here.
std::array<std::vector<uint32_t>,2> setup_local(size_t n,uint64_t seed) {
    Rng rng{seed^0x7363616e32303236ULL};std::array<std::vector<uint32_t>,2> stages;
    for(auto& p:stages) {
        p=permutation(n,rng);p.resize(n+1024,0);
        for(size_t i=1;i<n;++i)p[i]|=uint32_t(rng.below(40))<<21;
    }
    return stages;
}
template<int PF> void scan_local(const F* __restrict src,F* __restrict dst,
                                 const uint32_t* __restrict p,size_t n) {
    F state=src[p[0]&MASK21];dst[0]=state;size_t i=1;
    for(;i+3<n;i+=4) {
        if constexpr(PF) {
            __builtin_prefetch(src+(p[i+PF]&MASK21),0,1);
            __builtin_prefetch(src+(p[i+PF+1]&MASK21),0,1);
            __builtin_prefetch(src+(p[i+PF+2]&MASK21),0,1);
            __builtin_prefetch(src+(p[i+PF+3]&MASK21),0,1);
        }
        const uint32_t p0=p[i],p1=p[i+1],p2=p[i+2],p3=p[i+3];
        const F x0=src[p0&MASK21],x1=src[p1&MASK21],x2=src[p2&MASK21],x3=src[p3&MASK21];
        dst[i]=state=fp128::madd_small(state,(p0>>21)+1,x0);
        dst[i+1]=state=fp128::madd_small(state,(p1>>21)+1,x1);
        dst[i+2]=state=fp128::madd_small(state,(p2>>21)+1,x2);
        dst[i+3]=state=fp128::madd_small(state,(p3>>21)+1,x3);
    }
    for(;i<n;++i)dst[i]=state=fp128::madd_small(state,(p[i]>>21)+1,src[p[i]&MASK21]);
}

constexpr unsigned LOCAL_MATRIX[8][4]={{1,0,0,0},{1,1,0,0},{1,2,1,0},{1,3,3,1},
                                      {1,4,6,4},{1,5,10,10},{1,6,15,20},{0,0,0,1}};
void dense_local(const F* x,F* y,size_t k) {
    for(size_t i=0;i<k;i+=4)for(unsigned r=0;r<8;++r) {
        F sum=0;
        for(unsigned j=0;j<4;++j)sum=ref_add(sum,fp128::mul(x[i+j],LOCAL_MATRIX[r][j]));
        y[2*i+r]=sum;
    }
}

template<int Id> void selected_scan(const F* src,F* dst,const uint32_t* p,size_t n) {
    if constexpr(Id==0)scan_local<32>(src,dst,p,n);
    if constexpr(Id==1)fp128::scan_scheduled<16,4>(src,dst,p,n);
    if constexpr(Id==2)fp128::scan_scheduled<32,4>(src,dst,p,n);
    if constexpr(Id==3)fp128::scan_scheduled<64,4>(src,dst,p,n);
    if constexpr(Id==4)fp128::scan_scheduled<96,4>(src,dst,p,n);
    if constexpr(Id==5)fp128::scan_scheduled<128,4>(src,dst,p,n);
    if constexpr(Id==6)fp128::scan_scheduled<256,4>(src,dst,p,n);
    if constexpr(Id==7)fp128::scan_scheduled<64,8>(src,dst,p,n);
    if constexpr(Id==8)fp128::scan_scheduled<64,16>(src,dst,p,n);
    if constexpr(Id==9)fp128::scan_scheduled<64,4,3>(src,dst,p,n);
    if constexpr(Id==10)fp128::scan_tiled<32,64>(src,dst,p,n);
    if constexpr(Id==11)fp128::scan_tiled<64,128>(src,dst,p,n);
    if constexpr(Id==12)fp128::scan_tiled<128,256>(src,dst,p,n);
    if constexpr(Id==13)fp128::scan_explicit<64>(src,dst,p,n);
    if constexpr(Id==14)fp128::scan_explicit<128>(src,dst,p,n);
    if constexpr(Id==15)fp128::scan_scheduled<32,16>(src,dst,p,n);
    if constexpr(Id==16)fp128::scan_scheduled<128,16>(src,dst,p,n);
    if constexpr(Id==17)fp128::scan_scheduled<256,16>(src,dst,p,n);
    if constexpr(Id==18)fp128::scan_scheduled<64,32>(src,dst,p,n);
    if constexpr(Id==19)fp128::scan_scheduled<128,32>(src,dst,p,n);
    if constexpr(Id==20)fp128::scan_scheduled<32,4,1,true>(src,dst,p,n);
    if constexpr(Id==21)fp128::scan_scheduled<64,16,1,true>(src,dst,p,n);
    if constexpr(Id==22)fp128::scan_scheduled<128,16,1,true>(src,dst,p,n);
    if constexpr(Id==23)fp128::scan_explicit<96>(src,dst,p,n);
    if constexpr(Id==24)fp128::scan_explicit<192>(src,dst,p,n);
    if constexpr(Id==25)fp128::scan_explicit<256>(src,dst,p,n);
    if constexpr(Id==26)fp128::scan_explicit<384>(src,dst,p,n);
    if constexpr(Id==27)fp128::scan_explicit<512>(src,dst,p,n);
    if constexpr(Id==28)fp128::scan_pairs<128>(src,dst,p,n);
    if constexpr(Id==29)fp128::scan_pairs<256>(src,dst,p,n);
}
const std::vector<std::string> scan_names={"baseline","pf16_u4","pf32_u4","pf64_u4","pf96_u4","pf128_u4","pf256_u4","pf64_u8","pf64_u16","pf64_u4_l1","tile32_pf64","tile64_pf128","tile128_pf256","old_pf64","old_pf128","pf32_u16","pf128_u16","pf256_u16","pf64_u32","pf128_u32","relaxed_pf32_u4","relaxed_pf64_u16","relaxed_pf128_u16","old_pf96","old_pf192","old_pf256","old_pf384","old_pf512","pairs_pf128","pairs_pf256"};

template<int Id> void scan_test() {
    Rng rng{20260920};
    for(size_t n=1;n<=513;++n) {
        std::vector<F> input(n),output(n),expected(n);std::vector<uint32_t> packed(n+1024,0);
        for(size_t i=0;i<n;++i) {
            input[i]=i%3==0?P-1:(i%3==1?0:rng.field());
            packed[i]=uint32_t(rng.below(n))|(uint32_t(rng.below(40))<<21);
        }
        F state=input[packed[0]&MASK21];expected[0]=state;
        for(size_t i=1;i<n;++i)expected[i]=state=ref_add(input[packed[i]&MASK21],fp128::mul(state,(packed[i]>>21)+1));
        selected_scan<Id>(input.data(),output.data(),packed.data(),n);
        if(output!=expected)throw std::runtime_error("scan boundary/tail mismatch");
    }
}

template<int Id> void schedule_case(size_t k,int it,uint64_t seed) {
    const size_t n=2*k;Rng rng{seed};std::vector<F> input(k),a(n),b(n);
    for(F& x:input)x=rng.field();
    auto stages=setup_local(n,seed);
    std::vector<double> totals,locals,first,second;uint64_t hash=0;
    for(int run=-2;run<it;++run) {
        input[0]=add(input[0],1);auto t0=Clock::now();
        fp128::encode_block4_8<BlockKernel::contiguous>(input.data(),a.data(),k);auto t1=Clock::now();
        selected_scan<Id>(a.data(),b.data(),stages[0].data(),n);auto t2=Clock::now();
        selected_scan<Id>(b.data(),a.data(),stages[1].data(),n);auto t3=Clock::now();
        if(run>=0) {locals.push_back(ms(t0,t1));first.push_back(ms(t1,t2));second.push_back(ms(t2,t3));totals.push_back(ms(t0,t3));}
        hash=checksum(a);
    }
    std::vector<F> expected(n),temp(n);dense_local(input.data(),expected.data(),k);
    for(const auto& p:stages) {
        F state=expected[p[0]&MASK21];temp[0]=state;
        for(size_t i=1;i<n;++i)temp[i]=state=ref_add(expected[p[i]&MASK21],fp128::mul(state,(p[i]>>21)+1));
        expected.swap(temp);
    }
    if(a!=expected)throw std::runtime_error("complete encoder mismatch");
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"kernel\":\""<<scan_names[Id]<<"\",\"k\":"<<k<<",\"n\":"<<n
      <<",\"iterations\":"<<it<<",\"seed\":"<<seed<<",\"validated\":true,\"checksum\":"<<hash;
    print_stat("local_ms",locals);print_stat("stage0_ms",first);print_stat("stage1_ms",second);print_stat("total_ms",totals);
    std::cout<<"}\n"<<std::flush;
}

template<int Id=0> void dispatch(int id,size_t k,int it,uint64_t seed,bool test) {
    if(id==Id) {if(test)scan_test<Id>();schedule_case<Id>(k,it,seed);}
    else if constexpr(Id+1<30)dispatch<Id+1>(id,k,it,seed,test);
    else throw std::runtime_error("invalid case");
}
#ifndef SCAN_SCHEDULE_NO_MAIN
int main(int argc,char** argv) {
    try {
        int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        size_t k=1<<20;int it=9;uint64_t seed=20260918;bool reverse=false,test=false;int selected=-1;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto value=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--k")k=std::stoull(value());else if(arg=="--iterations")it=std::stoi(value());
            else if(arg=="--seed")seed=std::stoull(value());else if(arg=="--case")selected=std::stoi(value());
            else if(arg=="--reverse")reverse=true;else if(arg=="--test")test=true;else throw std::runtime_error("unknown option");
        }
        if(test){
            using boost::multiprecision::uint256_t;
            auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
            const F edges[]={0,1,158,159,(F(1)<<64)-1,F(1)<<64,P/2,P-1,P,P+1,F(-1)};
            for(F x:edges)for(F y:edges)if(y<P)for(unsigned m=1;m<=40;++m) {
                if(big(fp128::canonicalize(fp128::madd_relaxed(x,m,y)))!=(big(x)*m+big(y))%big(P))
                    throw std::runtime_error("relaxed arithmetic boundary mismatch");
            }
            Rng rng{20260920};
            for(unsigned j=0;j<100000;++j) {
                F x=(F(rng.next())<<64)|rng.next(),y=rng.field();unsigned m=rng.below(40)+1;
                if(big(fp128::canonicalize(fp128::madd_relaxed(x,m,y)))!=(big(x)*m+big(y))%big(P))
                    throw std::runtime_error("relaxed arithmetic random mismatch");
            }
            k=256;it=1;
        }
        if(k<4||k%4||k>(1u<<20)||it<1||selected < -1||selected>=30)throw std::runtime_error("invalid options");
        if(selected>=0)dispatch(selected,k,it,seed,test);
        else for(int j=0;j<30;++j)dispatch(reverse?29-j:j,k,it,seed,test);
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
#endif
