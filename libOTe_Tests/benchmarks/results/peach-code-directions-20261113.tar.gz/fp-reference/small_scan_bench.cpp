// Same field, timers, uniform-range fixture sampler, and exclusive lock as BAA.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main addition_only_harness_main
#include "encoder_bench.cpp"
#undef main
#pragma GCC diagnostic pop
#include "fp128_small.h"

constexpr uint32_t INDEX_BITS=21, INDEX_MASK=(1u<<INDEX_BITS)-1;
enum class SmallKernel { chain, small, general, fused };

const char* small_name(SmallKernel kernel) {
    switch(kernel) {
        case SmallKernel::chain:return "addition_chain";
        case SmallKernel::small:return "small_multiply";
        case SmallKernel::general:return "field_multiply";
        default:return "fused_small";
    }
}

inline void block4_8(const F* __restrict input,F* __restrict output) {
    F a=input[0], b=input[1], c=input[2];const F d=input[3];
    output[0]=a;output[7]=d;
    a=add(a,b);b=add(b,c);c=add(c,d);output[1]=a;
    a=add(a,b);b=add(b,c);c=add(c,d);output[2]=a;
    a=add(a,b);b=add(b,c);c=add(c,d);output[3]=a;
    a=add(a,b);b=add(b,c);c=add(c,d);output[4]=a;
    a=add(a,b);b=add(b,c);output[5]=a;
    a=add(a,b);output[6]=a;
}
void small_local(const F* __restrict input,F* __restrict output,size_t k) {
    for(size_t i=0;i<k;i+=4) block4_8(input+i,output+2*i);
}

template<bool Signed> inline F combine(F input,F value,uint32_t code) {
    if constexpr(Signed) {
        const F mask=F(0)-F((code>>5)&1);
        const F negative=(F(0)-value)-(F(159)&(F(0)-F(value!=0)));
        value=(value&~mask)|(negative&mask);
    }
    return add(input,value);
}

template<SmallKernel Kernel,bool Signed> inline F small_step(F state,F input,uint32_t code) {
    const uint32_t magnitude=(Signed?(code&31):code)+1;
    if constexpr(Kernel==SmallKernel::fused) {
        if constexpr(Signed) {
            if(code&32) return fp128::msub_small(state,magnitude,input);
        }
        return fp128::madd_small(state,magnitude,input);
    } else {
        F value;
        if constexpr(Kernel==SmallKernel::chain)
            value=fp128::mul_add_chain<Signed?20:40>(state,magnitude);
        else if constexpr(Kernel==SmallKernel::small) value=fp128::mul_small(state,magnitude);
        else value=fp128::mul_bmi2(state,F(magnitude));
        return combine<Signed>(input,value,code);
    }
}

template<SmallKernel Kernel,bool Signed,int PF> void small_stage(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict packed,size_t n) {
    F state=src[packed[0]&INDEX_MASK];dst[0]=state;
    size_t i=1;
    for(;i+3<n;i+=4) {
        if constexpr(PF) {
            __builtin_prefetch(src+(packed[i+PF]&INDEX_MASK),0,1);
            __builtin_prefetch(src+(packed[i+PF+1]&INDEX_MASK),0,1);
            __builtin_prefetch(src+(packed[i+PF+2]&INDEX_MASK),0,1);
            __builtin_prefetch(src+(packed[i+PF+3]&INDEX_MASK),0,1);
        }
        const uint32_t p0=packed[i],p1=packed[i+1],p2=packed[i+2],p3=packed[i+3];
        const F x0=src[p0&INDEX_MASK],x1=src[p1&INDEX_MASK];
        const F x2=src[p2&INDEX_MASK],x3=src[p3&INDEX_MASK];
        dst[i]=state=small_step<Kernel,Signed>(state,x0,p0>>INDEX_BITS);
        dst[i+1]=state=small_step<Kernel,Signed>(state,x1,p1>>INDEX_BITS);
        dst[i+2]=state=small_step<Kernel,Signed>(state,x2,p2>>INDEX_BITS);
        dst[i+3]=state=small_step<Kernel,Signed>(state,x3,p3>>INDEX_BITS);
    }
    for(;i<n;++i) {
        const uint32_t p=packed[i];
        dst[i]=state=small_step<Kernel,Signed>(state,src[p&INDEX_MASK],p>>INDEX_BITS);
    }
}

template<bool Signed> std::array<std::vector<uint32_t>,2> small_setup(size_t n,unsigned q,uint64_t seed) {
    Rng rng{seed^0x7363616e32303236ULL};
    std::array<std::vector<uint32_t>,2> stages;
    for(auto& stage:stages) {
        stage=permutation(n,rng);
        for(size_t i=1;i<n;++i) {
            const unsigned choice=rng.below(q);
            unsigned code=choice;
            if constexpr(Signed) code=(choice%(q/2))|((choice/(q/2))<<5);
            stage[i]|=code<<INDEX_BITS;
        }
    }
    return stages;
}

F reference_step(F state,F input,unsigned code,bool is_signed) {
    unsigned magnitude=(is_signed?(code&31):code)+1;
    F value=fp128::mul(state,magnitude);
    if(is_signed && (code&32)) value=value?P-value:0;
    return ref_add(input,value);
}
void reference_small(const std::vector<F>& input,std::vector<F>& out,
                     const std::array<std::vector<uint32_t>,2>& stages,bool is_signed) {
    const size_t k=input.size(),n=2*k;std::vector<F> a(n),b(n);
    constexpr unsigned matrix[8][4]={{1,0,0,0},{1,1,0,0},{1,2,1,0},{1,3,3,1},
                                     {1,4,6,4},{1,5,10,10},{1,6,15,20},{0,0,0,1}};
    for(size_t i=0;i<k;i+=4) for(unsigned row=0;row<8;++row) {
        F value=0;
        for(unsigned j=0;j<4;++j) value=ref_add(value,fp128::mul(input[i+j],matrix[row][j]));
        a[2*i+row]=value;
    }
    for(const auto& stage:stages) {
        F state=a[stage[0]&INDEX_MASK];b[0]=state;
        for(size_t i=1;i<n;++i) b[i]=state=reference_step(state,a[stage[i]&INDEX_MASK],stage[i]>>INDEX_BITS,is_signed);
        a.swap(b);
    }
    out=std::move(a);
}

template<SmallKernel Kernel,bool Signed,int PF> void small_case(size_t k,unsigned q,int iterations,uint64_t seed) {
    const size_t n=2*k;auto start=Clock::now();Rng rng{seed};
    std::vector<F> input(k),a(n),b(n);for(F& x:input)x=rng.field();
    auto stages=small_setup<Signed>(n,q,seed);
    const double setup_ms=ms(start,Clock::now());
    std::vector<double> local,first,second,total;uint64_t hash=0;
    for(int run=-2;run<iterations;++run) {
        input[0]=add(input[0],1);auto t0=Clock::now();
        small_local(input.data(),a.data(),k);auto t1=Clock::now();
        small_stage<Kernel,Signed,PF>(a.data(),b.data(),stages[0].data(),n);auto t2=Clock::now();
        small_stage<Kernel,Signed,PF>(b.data(),a.data(),stages[1].data(),n);auto t3=Clock::now();
        if(run>=0) {local.push_back(ms(t0,t1));first.push_back(ms(t1,t2));second.push_back(ms(t2,t3));total.push_back(ms(t0,t3));}
        hash=checksum(a);
    }
    std::vector<F> expected;reference_small(input,expected,stages,Signed);
    if(a!=expected)throw std::runtime_error("full-output mismatch");
    const size_t payload=(input.capacity()+a.capacity()+b.capacity())*16+(stages[0].capacity()+stages[1].capacity())*4;
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"case\":\"small_scan\",\"kernel\":\""<<small_name(Kernel)
      <<"\",\"q\":"<<q<<",\"signed\":"<<(Signed?"true":"false")<<",\"k\":"<<k<<",\"n\":"<<n
      <<",\"prefetch\":"<<PF<<",\"iterations\":"<<iterations<<",\"seed\":"<<seed<<",\"validated\":true"
      <<",\"setup_ms\":"<<setup_ms<<",\"resident_payload_bytes\":"<<payload<<",\"checksum\":"<<hash;
    print_stat("local_ms",local);print_stat("stage0_ms",first);print_stat("stage1_ms",second);print_stat("total_ms",total);
    std::cout<<"}\n"<<std::flush;
}

void small_arithmetic_tests() {
    using boost::multiprecision::uint256_t;
    auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto narrow=[](uint256_t x){return (F(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto check=[&](F x,F input,unsigned m) {
        F product=narrow(big(x)*m%big(P));
        F sum=narrow((big(x)*m+big(input))%big(P));
        F difference=narrow((big(input)+big(P)-big(product))%big(P));
        const std::array<F,5> actual={fp128::mul_small(x,m),fp128::mul_add_chain<40>(x,m),
                                     fp128::mul_bmi2(x,F(m)),fp128::madd_small(x,m,input),fp128::msub_small(x,m,input)};
        const std::array<F,5> expected={product,product,product,sum,difference};
        for(unsigned j=0;j<5;++j) if(actual[j]!=expected[j]) {
            std::cerr<<"arithmetic kernel="<<j<<" m="<<m<<" x="<<big(x)<<" input="<<big(input)
                     <<" actual="<<big(actual[j])<<" expected="<<big(expected[j])<<'\n';
            throw std::runtime_error("small arithmetic mismatch");
        }
    };
    std::vector<F> edges={0,1,2,158,159,160,F(1)<<64,(F(1)<<64)-1,P/2,P-1,P-2,P-159,P-160};
    for(unsigned m=1;m<=40;++m) {
        if(P/m<P)edges.push_back(P/m);
        if(P/m)edges.push_back(P/m-1);
        if(P/m+1<P)edges.push_back(P/m+1);
    }
    for(F x:edges)for(F y:edges)for(unsigned m=1;m<=40;++m)check(x,y,m);
    Rng rng{0x20260918};
    for(unsigned i=0;i<1000000;++i)check(rng.field(),rng.field(),1+rng.below(40));
    std::cout<<"{\"test\":\"small_arithmetic\",\"random_cases\":1000000,\"boundary_cases\":"
             <<edges.size()*edges.size()*40<<",\"passed\":true}\n"<<std::flush;
}

template<bool Signed,int PF> void dispatch_small(const std::string& name,size_t k,unsigned q,int it,uint64_t seed) {
    if(name=="addition_chain")small_case<SmallKernel::chain,Signed,PF>(k,q,it,seed);
    else if(name=="small_multiply")small_case<SmallKernel::small,Signed,PF>(k,q,it,seed);
    else if(name=="field_multiply")small_case<SmallKernel::general,Signed,PF>(k,q,it,seed);
    else if(name=="fused_small")small_case<SmallKernel::fused,Signed,PF>(k,q,it,seed);
    else throw std::runtime_error("unknown small kernel");
}

int main(int argc,char** argv) {
    try {
        int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        std::string mode="encoders",kernel="all",sign="both";size_t k=1<<20;
        unsigned q=40;int iterations=9,pf=32;uint64_t seed=20260918;bool reverse=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto value=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--mode")mode=value();else if(arg=="--kernel")kernel=value();else if(arg=="--sign")sign=value();
            else if(arg=="--q")q=std::stoul(value());else if(arg=="--k")k=std::stoull(value());
            else if(arg=="--iterations")iterations=std::stoi(value());else if(arg=="--seed")seed=std::stoull(value());
            else if(arg=="--prefetch")pf=std::stoi(value());else if(arg=="--reverse")reverse=true;
            else throw std::runtime_error("unknown option");
        }
        if(mode=="test") {small_arithmetic_tests();k=256;iterations=1;}
        if((mode!="test"&&mode!="encoders") || k<4 || k%4 || k>(1u<<20) || (q!=32&&q!=40) || iterations<1 ||
           (pf!=0&&pf!=32) || (sign!="both"&&sign!="positive"&&sign!="signed"))throw std::runtime_error("invalid options");
        std::vector<std::string> kernels={"addition_chain","small_multiply","field_multiply","fused_small"};
        if(kernel!="all")kernels={kernel};
        if(reverse)std::reverse(kernels.begin(),kernels.end());
        std::vector<bool> signs={false,true};
        if(sign!="both")signs={sign=="signed"};
        if(reverse)std::reverse(signs.begin(),signs.end());
        for(bool s:signs)for(const auto& name:kernels) {
            if(s) {if(pf)dispatch_small<true,32>(name,k,q,iterations,seed);else dispatch_small<true,0>(name,k,q,iterations,seed);}
            else {if(pf)dispatch_small<false,32>(name,k,q,iterations,seed);else dispatch_small<false,0>(name,k,q,iterations,seed);}
        }
        return 0;
    }catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
