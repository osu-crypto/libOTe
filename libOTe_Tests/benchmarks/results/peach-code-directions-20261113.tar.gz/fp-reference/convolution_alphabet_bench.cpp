#define SCAN_SCHEDULE_NO_MAIN
#include "scan_schedule_bench.cpp"
#include "fp128_convolution_alphabet.h"

template<int Id> struct Config;
#define CONFIG(ID,NAME,...) template<> struct Config<ID>{using A=fp128::__VA_ARGS__;static constexpr const char* name=NAME;};
CONFIG(0,"q3_word32",ConvolutionAlphabet<3,2>)
CONFIG(1,"q8_word32",ConvolutionAlphabet<8,3>)
CONFIG(2,"q16_word32",ConvolutionAlphabet<16,4>)
CONFIG(3,"q32_word32",ConvolutionAlphabet<32,5>)
CONFIG(4,"q32_q64_word32",ConvolutionAlphabet<32,5,64,6>)
CONFIG(5,"q256_word64",ConvolutionAlphabet<256,8>)
CONFIG(6,"q65536_word64",ConvolutionAlphabet<65536,16>)
CONFIG(7,"q2097152_word64",ConvolutionAlphabet<2097152,21>)
CONFIG(8,"q32_word64",ConvolutionAlphabet<32,5,32,5,true>)
CONFIG(9,"q4294967295_word96",ConvolutionFull32)
#undef CONFIG
constexpr int ALPHABET_CASES=10;

template<class A> auto alphabet_setup(size_t n,uint64_t seed) {
    Rng perm_rng{seed^0x636f6e7632303236ULL},coeff_rng{seed^0x7461707332303236ULL};
    std::array<std::vector<typename A::Word>,2> stages;
    for(auto& p:stages) {
        const auto indices=permutation(n,perm_rng);p.resize(n+1024);
        for(size_t i=0;i<n;++i) {
            const unsigned a=coeff_rng.below(A::qa)+1,b=coeff_rng.below(A::qb)+1;
            p[i]=A::pack(indices[i],a,b);
        }
    }
    return stages;
}
template<class A> void alphabet_reference(const F* src,F* dst,const typename A::Word* p,size_t n) {
    F prev=0,older=0;
    for(size_t i=0;i<n;++i) {
        const F out=ref_add(ref_add(src[A::index(p[i])],fp128::mul(prev,A::a(p[i]))),fp128::mul(older,A::b(p[i])));
        dst[i]=out;older=prev;prev=out;
    }
}
void alphabet_arithmetic_test() {
    using boost::multiprecision::uint256_t;
    auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto check=[&](F x,F y,F z,unsigned a,unsigned b) {
        const auto input=_mm_loadu_si128(reinterpret_cast<const __m128i*>(&z));
        const auto expected=(big(x)*a+big(y)*b+big(z))%big(P);
        if(big(fp128::conv_madd_mulx(x,a,y,b,input))!=expected ||
           big(ref_add(ref_add(z,fp128::mul(x,a)),fp128::mul(y,b)))!=expected)
            throw std::runtime_error("wide coefficient arithmetic mismatch");
    };
    const F edges[]={0,1,159,(F(1)<<64)-1,F(1)<<64,P/2,P-2,P-1};
    const unsigned coefficients[]={1,2,3,8,16,32,64,256,65536,2097152,UINT32_MAX};
    for(F x:edges)for(F y:edges)for(F z:edges)for(unsigned a:coefficients)for(unsigned b:coefficients)check(x,y,z,a,b);
    Rng rng{20260919};
    for(unsigned i=0;i<100000;++i) {
        const unsigned a=unsigned(rng.next()),b=unsigned(rng.next());
        check(rng.field(),rng.field(),rng.field(),a?a:1,b?b:1);
    }
}
template<class A> void alphabet_test() {
    Rng rng{20260919};
    for(size_t n=0;n<=513;++n) {
        std::vector<F> input(n),actual(n),expected(n);std::vector<typename A::Word> p(n+1024);
        for(size_t i=0;i<n;++i) {
            input[i]=i%3==0?P-1:(i%3==1?0:rng.field());
            const uint32_t index=rng.below(n);
            const unsigned a=i%3==0?A::qa:unsigned(rng.below(A::qa)+1);
            const unsigned b=i%3==1?A::qb:unsigned(rng.below(A::qb)+1);
            p[i]=A::pack(index,a,b);
            if(A::index(p[i])!=index || A::a(p[i])!=a || A::b(p[i])!=b)throw std::runtime_error("metadata roundtrip mismatch");
        }
        // Check the largest valid index and both maximum coefficients as well.
        const auto edge=A::pack(MASK21,A::qa,A::qb);
        if(A::index(edge)!=MASK21 || A::a(edge)!=A::qa || A::b(edge)!=A::qb)throw std::runtime_error("metadata maximum mismatch");
        alphabet_reference<A>(input.data(),expected.data(),p.data(),n);
        fp128::convolution_alphabet<A>(input.data(),actual.data(),p.data(),n);
        if(actual!=expected)throw std::runtime_error("alphabet scan mismatch");
    }
}
template<int Id> void alphabet_case(size_t k,int it,uint64_t seed) {
    using A=typename Config<Id>::A;
    const size_t n=2*k;Rng rng{seed};std::vector<F> input(k),a(n),b(n);
    for(F& x:input)x=rng.field();
    auto stages=alphabet_setup<A>(n,seed);
    std::vector<double> totals,locals,first,second;uint64_t hash=0;
    for(int run=-2;run<it;++run) {
        input[0]=add(input[0],1);auto t0=Clock::now();
        fp128::encode_block4_8<BlockKernel::contiguous>(input.data(),a.data(),k);auto t1=Clock::now();
        fp128::convolution_alphabet<A>(a.data(),b.data(),stages[0].data(),n);auto t2=Clock::now();
        fp128::convolution_alphabet<A>(b.data(),a.data(),stages[1].data(),n);auto t3=Clock::now();
        if(run>=0){locals.push_back(ms(t0,t1));first.push_back(ms(t1,t2));second.push_back(ms(t2,t3));totals.push_back(ms(t0,t3));}
        hash=checksum(a);
    }
    std::vector<F> expected(n),temp(n);dense_local(input.data(),expected.data(),k);
    for(const auto& p:stages){alphabet_reference<A>(expected.data(),temp.data(),p.data(),n);expected.swap(temp);}
    if(a!=expected)throw std::runtime_error("complete alphabet encoder mismatch");
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"kernel\":\""<<Config<Id>::name<<"\",\"qa\":"<<A::qa<<",\"qb\":"<<A::qb
      <<",\"metadata_bytes\":"<<sizeof(typename A::Word)<<",\"k\":"<<k<<",\"n\":"<<n
      <<",\"payload_bytes\":"<<(16*(k+2*n)+2*(n+1024)*sizeof(typename A::Word))
      <<",\"iterations\":"<<it<<",\"seed\":"<<seed<<",\"validated\":true,\"checksum\":"<<hash;
    print_stat("local_ms",locals);print_stat("stage0_ms",first);print_stat("stage1_ms",second);print_stat("total_ms",totals);
    std::cout<<"}\n"<<std::flush;
}
template<int Id=0> void alphabet_dispatch(int id,size_t k,int it,uint64_t seed,bool test) {
    if(id==Id){if(test)alphabet_test<typename Config<Id>::A>();alphabet_case<Id>(k,it,seed);}
    else if constexpr(Id+1<ALPHABET_CASES)alphabet_dispatch<Id+1>(id,k,it,seed,test);
    else throw std::runtime_error("invalid case");
}
int main(int argc,char** argv) {
    try {
        int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        int spin_lock=open("/tmp/bare-spin-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(spin_lock<0||flock(spin_lock,LOCK_EX|LOCK_NB))throw std::runtime_error("SPIN benchmark lock unavailable");
        size_t k=1<<20;int it=9,selected=-1;uint64_t seed=20260919;bool test=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto value=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--k")k=std::stoull(value());else if(arg=="--iterations")it=std::stoi(value());
            else if(arg=="--seed")seed=std::stoull(value());else if(arg=="--case")selected=std::stoi(value());
            else if(arg=="--test")test=true;else throw std::runtime_error("unknown option");
        }
        if(test){alphabet_arithmetic_test();k=256;it=1;}
        if(k<4||k%4||k>(1u<<20)||it<1||selected < -1||selected>=ALPHABET_CASES)throw std::runtime_error("invalid options");
        if(selected>=0)alphabet_dispatch(selected,k,it,seed,test);
        else for(int id=0;id<ALPHABET_CASES;++id)alphabet_dispatch(id,k,it,seed,test);
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
