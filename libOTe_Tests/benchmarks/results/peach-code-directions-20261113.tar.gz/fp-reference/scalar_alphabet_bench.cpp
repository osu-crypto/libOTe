#define SCAN_SCHEDULE_NO_MAIN
#include "scan_schedule_bench.cpp"

constexpr unsigned ALPHABETS[]={40,64,128,256,512,1024,2048};
auto scalar_setup(size_t n,uint64_t seed,unsigned q) {
    Rng rng{seed^0x7363616e32303236ULL};std::array<std::vector<uint32_t>,2> stages;
    for(auto& p:stages) {
        p=permutation(n,rng);p.resize(n+1024,0);
        for(size_t i=1;i<n;++i)p[i]|=uint32_t(rng.below(q))<<21;
    }
    return stages;
}
void scalar_reference(const F* src,F* dst,const uint32_t* p,size_t n) {
    F state=0;
    for(size_t i=0;i<n;++i)dst[i]=state=ref_add(src[p[i]&MASK21],fp128::mul(state,(p[i]>>21)+1));
}
void scalar_test() {
    using boost::multiprecision::uint256_t;
    auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
    const F edge[]={0,1,158,159,(F(1)<<64)-1,F(1)<<64,P/2,P-2,P-1};
    for(F x:edge)for(F y:edge)for(unsigned m=1;m<=2048;++m)
        if(big(fp128::madd_small(x,m,y))!=(big(x)*m+big(y))%big(P) ||
           big(fp128::mul_small(x,m))!=big(x)*m%big(P))throw std::runtime_error("scalar arithmetic edge mismatch");
    Rng rng{20260921};
    for(unsigned i=0;i<100000;++i) {
        const F x=rng.field(),y=rng.field();const unsigned m=unsigned(rng.below(2048)+1);
        if(big(fp128::madd_small(x,m,y))!=(big(x)*m+big(y))%big(P))throw std::runtime_error("scalar arithmetic random mismatch");
    }
    for(unsigned q:ALPHABETS)for(size_t n=0;n<=513;++n) {
        std::vector<F> src(n),dst(n),ref(n);std::vector<uint32_t> p(n+1024);
        for(size_t i=0;i<n;++i) {
            src[i]=i%3==0?P-1:i%3==1?0:rng.field();
            p[i]=uint32_t(rng.below(n))|(uint32_t(i%2?q-1:rng.below(q))<<21);
        }
        fp128::scan_scheduled<256,16>(src.data(),dst.data(),p.data(),n);
        scalar_reference(src.data(),ref.data(),p.data(),n);
        if(dst!=ref)throw std::runtime_error("scalar scan mismatch");
    }
    if(((MASK21|((2048u-1)<<21))>>21)+1!=2048)throw std::runtime_error("packing mismatch");
}
void scalar_case(unsigned q,size_t k,int it,uint64_t seed) {
    const size_t n=2*k;Rng rng{seed};std::vector<F> input(k),a(n),b(n);
    for(F& x:input)x=rng.field();auto stages=scalar_setup(n,seed,q);
    std::vector<double> totals,locals,first,second;uint64_t hash=0;
    for(int run=-2;run<it;++run) {
        input[0]=add(input[0],1);auto t0=Clock::now();
        fp128::encode_block4_8<BlockKernel::contiguous>(input.data(),a.data(),k);auto t1=Clock::now();
        fp128::scan_scheduled<256,16>(a.data(),b.data(),stages[0].data(),n);auto t2=Clock::now();
        fp128::scan_scheduled<256,16>(b.data(),a.data(),stages[1].data(),n);auto t3=Clock::now();
        if(run>=0){locals.push_back(ms(t0,t1));first.push_back(ms(t1,t2));second.push_back(ms(t2,t3));totals.push_back(ms(t0,t3));}
        hash=checksum(a);
    }
    std::vector<F> expected(n),temp(n);dense_local(input.data(),expected.data(),k);
    for(const auto& p:stages){scalar_reference(expected.data(),temp.data(),p.data(),n);expected.swap(temp);}
    if(a!=expected)throw std::runtime_error("complete scalar encoder mismatch");
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"kernel\":\"scalar_q"<<q<<"\",\"q\":"<<q<<",\"k\":"<<k<<",\"n\":"<<n
      <<",\"payload_bytes\":"<<(16*(k+2*n)+8*(n+1024))<<",\"iterations\":"<<it<<",\"seed\":"<<seed<<",\"validated\":true,\"checksum\":"<<hash;
    print_stat("local_ms",locals);print_stat("stage0_ms",first);print_stat("stage1_ms",second);print_stat("total_ms",totals);
    std::cout<<"}\n"<<std::flush;
}
int main(int argc,char** argv) {
    try {
        int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        int spin_lock=open("/tmp/bare-spin-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(spin_lock<0||flock(spin_lock,LOCK_EX|LOCK_NB))throw std::runtime_error("SPIN benchmark lock unavailable");
        size_t k=1<<20;int it=31;unsigned q=40;uint64_t seed=20260918;bool test=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto value=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--q")q=std::stoul(value());else if(arg=="--iterations")it=std::stoi(value());
            else if(arg=="--seed")seed=std::stoull(value());else if(arg=="--test")test=true;else throw std::runtime_error("unknown option");
        }
        if(q<1||q>2048||it<1)throw std::runtime_error("invalid options");
        if(test){scalar_test();for(unsigned alphabet:ALPHABETS)scalar_case(alphabet,256,1,seed);}
        else scalar_case(q,k,it,seed);
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
