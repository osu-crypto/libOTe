// Bounded q1 scheduling experiment. The runner extracts the archived small-q
// harness before main into this include; production sources stay unchanged.
#include "width_one_small_q_probe_shared.inc"

namespace fp128 {
template<unsigned B> inline void blocked_prefix_scan(
        const F* __restrict src,F* __restrict dst,
        const uint32_t* __restrict p,size_t n) {
    static_assert(B==4 || B==8 || B==16);
    if(!n)return;
    F state=src[p[0]&MASK21];dst[0]=state;size_t i=1;
    for(;i+16<=n;i+=16) {
        F prefix[16];
        #pragma GCC unroll 16
        for(unsigned j=0;j<16;++j) {
            __builtin_prefetch(src+(p[i+256+j]&MASK21),0,1);
            prefix[j]=src[p[i+j]&MASK21];
        }
        // Prefixes in different blocks are independent of each other and of
        // the incoming carry. Keep the same 16-input gather as the control.
        #pragma GCC unroll 4
        for(unsigned base=0;base<16;base+=B) {
            #pragma GCC unroll 16
            for(unsigned j=1;j<B;++j)
                prefix[base+j]=add_asm(prefix[base+j-1],prefix[base+j]);
        }
        #pragma GCC unroll 4
        for(unsigned base=0;base<16;base+=B) {
            const F incoming=state;
            // One carry dependency per block. The output offsets below are
            // mutually independent, and can overlap the next carry update.
            state=add_asm(incoming,prefix[base+B-1]);
            #pragma GCC unroll 16
            for(unsigned j=0;j<B-1;++j)
                dst[i+base+j]=add_asm(incoming,prefix[base+j]);
            dst[i+base+B-1]=state;
        }
    }
    for(;i<n;++i)dst[i]=state=add_asm(state,src[p[i]&MASK21]);
}
}

template<unsigned B> struct BlockedConfig:SmallQConfig<1,true> {
    static const char* name() {
        if constexpr(B==4)return "w1_q1_block4";
        if constexpr(B==8)return "w1_q1_block8";
        return "w1_q1_block16";
    }
    static void scan(const F* src,F* dst,const Word* p,size_t n) {
        fp128::blocked_prefix_scan<B>(src,dst,p,n);
    }
};
template<> struct CertifiedConfig<13>:BlockedConfig<4>{};
template<> struct CertifiedConfig<14>:BlockedConfig<8>{};
template<> struct CertifiedConfig<15>:BlockedConfig<16>{};

int main(int argc,char** argv) {
    try {
        for(const char* path:{"/tmp/prindal-addition-encoder-benchmark.lock","/tmp/bare-spin-benchmark.lock","/tmp/hypercat-benchmark.lock"}) {
            const int fd=open(path,O_CREAT|O_RDWR,0600);
            if(fd<0||flock(fd,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        }
        if(argc!=2)throw std::runtime_error("expected test or block size 1,4,8,16");
        const std::string arg=argv[1];
        if(arg=="test") {
            certified_test<4>();certified_test<13>();certified_test<14>();certified_test<15>();
            certified_case<4>(256,1,20260923);certified_case<13>(256,1,20260923);
            certified_case<14>(256,1,20260923);certified_case<15>(256,1,20260923);
        }else {
            const unsigned b=unsigned(std::stoul(arg));
            if(b==1)certified_case<4>(1u<<18,101,20260923);
            else if(b==4)certified_case<13>(1u<<18,101,20260923);
            else if(b==8)certified_case<14>(1u<<18,101,20260923);
            else if(b==16)certified_case<15>(1u<<18,101,20260923);
            else throw std::runtime_error("invalid block size");
        }
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
