#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main imported_encoder_main
#include "encoder_bench.cpp"
#undef main
#pragma GCC diagnostic pop
#include "fp128_small.h"
#include "fp128_block4_8.h"

using BlockKernel=fp128::LocalKernel;
constexpr uint32_t MASK21=(1u<<21)-1;
const char* local_name(BlockKernel k) {
    if(k==BlockKernel::baseline)return "baseline";
    if(k==BlockKernel::lazy)return "lazy_scalar";
    if(k==BlockKernel::avx512)return "avx512_limb43";
    return "avx512_contiguous";
}

// Same packed metadata, setup stream, unrolled gather loop and fused positive
// scan as small_scan_bench.cpp; B is the only variable under comparison.
std::array<std::vector<uint32_t>,2> setup_local(size_t n,uint64_t seed) {
    Rng rng{seed^0x7363616e32303236ULL};std::array<std::vector<uint32_t>,2> stages;
    for(auto& p:stages) {
        p=permutation(n,rng);
        for(size_t i=1;i<n;++i)p[i]|=uint32_t(rng.below(40))<<21;
    }
    return stages;
}
template<int PF> void scan_local(const F* __restrict src,F* __restrict dst,
                                 const uint32_t* __restrict p,size_t n) {
    F state=src[p[0]&MASK21];dst[0]=state;size_t i=1;
    for(;i+3<n;i+=4) {
        if constexpr(PF) {
            __builtin_prefetch(src+(p[i+PF]&MASK21),0,1);
            __builtin_prefetch(src+(p[i+PF+1]&MASK21),0,1);
            __builtin_prefetch(src+(p[i+PF+2]&MASK21),0,1);
            __builtin_prefetch(src+(p[i+PF+3]&MASK21),0,1);
        }
        const uint32_t p0=p[i],p1=p[i+1],p2=p[i+2],p3=p[i+3];
        const F x0=src[p0&MASK21],x1=src[p1&MASK21],x2=src[p2&MASK21],x3=src[p3&MASK21];
        dst[i]=state=fp128::madd_small(state,(p0>>21)+1,x0);
        dst[i+1]=state=fp128::madd_small(state,(p1>>21)+1,x1);
        dst[i+2]=state=fp128::madd_small(state,(p2>>21)+1,x2);
        dst[i+3]=state=fp128::madd_small(state,(p3>>21)+1,x3);
    }
    for(;i<n;++i)dst[i]=state=fp128::madd_small(state,(p[i]>>21)+1,src[p[i]&MASK21]);
}

constexpr unsigned LOCAL_MATRIX[8][4]={{1,0,0,0},{1,1,0,0},{1,2,1,0},{1,3,3,1},
                                      {1,4,6,4},{1,5,10,10},{1,6,15,20},{0,0,0,1}};
void dense_local(const F* x,F* y,size_t k) {
    for(size_t i=0;i<k;i+=4)for(unsigned r=0;r<8;++r) {
        F sum=0;
        for(unsigned j=0;j<4;++j)sum=ref_add(sum,fp128::mul(x[i+j],LOCAL_MATRIX[r][j]));
        y[2*i+r]=sum;
    }
}
void local_tests() {
    using boost::multiprecision::uint256_t;
    auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto narrow=[](uint256_t x){return (F(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto check=[&](const std::vector<F>& input) {
        size_t k=input.size();std::vector<F> expected(2*k),base(2*k),lazy(2*k),simd(2*k),contiguous(2*k);
        for(size_t i=0;i<k;i+=4)for(unsigned r=0;r<8;++r) {
            uint256_t sum=0;
            for(unsigned j=0;j<4;++j)sum+=big(input[i+j])*LOCAL_MATRIX[r][j];
            expected[2*i+r]=narrow(sum%big(P));
        }
        fp128::encode_block4_8<BlockKernel::baseline>(input.data(),base.data(),k);
        fp128::encode_block4_8<BlockKernel::lazy>(input.data(),lazy.data(),k);
        fp128::encode_block4_8<BlockKernel::avx512>(input.data(),simd.data(),k);
        fp128::encode_block4_8<BlockKernel::contiguous>(input.data(),contiguous.data(),k);
        if(base!=expected || lazy!=expected || simd!=expected || contiguous!=expected)throw std::runtime_error("local block oracle mismatch");
    };
    const std::array<F,12> edges={0,1,2,158,159,F(1)<<43,(F(1)<<43)-1,F(1)<<64,(F(1)<<64)-1,P/2,P-1,P-159};
    std::vector<F> input(32);
    for(F a:edges)for(F b:edges)for(F c:edges)for(F d:edges) {
        for(unsigned lane=0;lane<8;++lane) {
            const std::array<F,4> block={a,b,c,d};
            for(unsigned j=0;j<4;++j)input[4*lane+j]=block[(j+lane)%4];
        }
        check(input);
    }
    Rng rng{20260919};
    for(unsigned batch=0;batch<12500;++batch) {for(F& x:input)x=rng.field();check(input);}
    for(size_t k=4;k<=128;k+=4) {
        input.resize(k);for(F& x:input)x=rng.field();check(input);
        for(size_t basis=0;basis<k;++basis) {std::fill(input.begin(),input.end(),0);input[basis]=1;check(input);}
    }
    std::cout<<"{\"test\":\"block4_8\",\"passed\":true,\"boundary_blocks\":165888,\"random_blocks\":100000,\"basis_and_tail_sizes\":32}\n"<<std::flush;
}

template<BlockKernel Kernel> void local_case(size_t k,int iterations,uint64_t seed,bool only_local) {
    const size_t n=2*k;Rng rng{seed};std::vector<F> input(k),a(n),b(n);
    for(F& x:input)x=rng.field();
    auto stages=setup_local(n,seed);
    std::vector<double> totals,locals,first,second;uint64_t hash=0;
    for(int run=-2;run<iterations;++run) {
        input[0]=add(input[0],1);auto t0=Clock::now();
        fp128::encode_block4_8<Kernel>(input.data(),a.data(),k);auto t1=Clock::now();
        if(!only_local)scan_local<32>(a.data(),b.data(),stages[0].data(),n);
        auto t2=Clock::now();
        if(!only_local)scan_local<32>(b.data(),a.data(),stages[1].data(),n);
        auto t3=Clock::now();
        if(run>=0) {locals.push_back(ms(t0,t1));first.push_back(ms(t1,t2));second.push_back(ms(t2,t3));totals.push_back(ms(t0,t3));}
        hash=checksum(a);
    }
    std::vector<F> expected(n),temp(n);dense_local(input.data(),expected.data(),k);
    if(!only_local)for(const auto& p:stages) {
        F state=expected[p[0]&MASK21];temp[0]=state;
        for(size_t i=1;i<n;++i)temp[i]=state=ref_add(expected[p[i]&MASK21],fp128::mul(state,(p[i]>>21)+1));
        expected.swap(temp);
    }
    if(a!=expected)throw std::runtime_error("complete encoder mismatch");
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"case\":\""<<(only_local?"local_only":"complete")
      <<"\",\"kernel\":\""<<local_name(Kernel)<<"\",\"k\":"<<k<<",\"n\":"<<n
      <<",\"iterations\":"<<iterations<<",\"seed\":"<<seed<<",\"validated\":true,\"checksum\":"<<hash;
    print_stat("local_ms",locals);print_stat("stage0_ms",first);print_stat("stage1_ms",second);print_stat("total_ms",totals);
    std::cout<<"}\n"<<std::flush;
}

int main(int argc,char** argv) {
    try {
        int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        std::string mode="complete",kernel="all";size_t k=1<<20;int it=9;uint64_t seed=20260918;bool reverse=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto value=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--mode")mode=value();else if(arg=="--kernel")kernel=value();else if(arg=="--k")k=std::stoull(value());
            else if(arg=="--iterations")it=std::stoi(value());else if(arg=="--seed")seed=std::stoull(value());
            else if(arg=="--reverse")reverse=true;else throw std::runtime_error("unknown option");
        }
        if(!__builtin_cpu_supports("avx512f"))throw std::runtime_error("AVX512 required for this comparison");
        if(mode=="test") {local_tests();k=256;it=1;}
        if(k<4||k%4||k>(1u<<20)||it<1||(mode!="complete"&&mode!="local"&&mode!="test"))throw std::runtime_error("invalid options");
        std::vector<std::string> cases={"baseline","lazy_scalar","avx512_limb43","avx512_contiguous"};
        if(kernel!="all")cases={kernel};
        if(reverse)std::reverse(cases.begin(),cases.end());
        for(const auto& name:cases) {
            if(name=="baseline")local_case<BlockKernel::baseline>(k,it,seed,mode=="local");
            else if(name=="lazy_scalar")local_case<BlockKernel::lazy>(k,it,seed,mode=="local");
            else if(name=="avx512_limb43")local_case<BlockKernel::avx512>(k,it,seed,mode=="local");
            else if(name=="avx512_contiguous")local_case<BlockKernel::contiguous>(k,it,seed,mode=="local");
            else throw std::runtime_error("unknown local kernel");
        }
        return 0;
    }catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
