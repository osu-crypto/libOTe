#pragma once
#include "fp128_small.h"

namespace fp128 {
constexpr uint32_t conv_index_mask=(1u<<21)-1;
inline unsigned conv_a(uint32_t p) { return ((p>>21)&3)+1; }
inline unsigned conv_b(uint32_t p) { return ((p>>23)&3)+1; }

// Canonical inputs, a<=12,b<=9 (direct steps use a,b<=3). The high excess
// is at most 21; fold once through the existing canonical field add.
// No full field multiplication.
inline F conv_madd(F x,unsigned a,F y,unsigned b,F input) {
    const F lo=F(uint64_t(x))*a+F(uint64_t(y))*b+uint64_t(input);
    const F hi=F(uint64_t(x>>64))*a+F(uint64_t(y>>64))*b+
               uint64_t(input>>64)+(lo>>64);
    return add((hi<<64)|uint64_t(lo),(hi>>64)*159);
}

// Prepare the two future uses of this output, sharing doubles/triples.
// Eager=true trades the unpredictable preparation branches for two additions.
template<bool Eager,bool Masked=false> inline void conv_prepare(F y,unsigned a,unsigned b,F& first,F& second) {
    F twice=y,thrice=y;
    if(Eager || a>1 || b>1)twice=add(y,y);
    if(Eager || a==3 || b==3)thrice=add(twice,y);
    if constexpr(Masked) {
        const F one_a=F(0)-F(a==1),three_a=F(0)-F(a==3);
        const F one_b=F(0)-F(b==1),three_b=F(0)-F(b==3);
        first=(y&one_a)|(twice&~(one_a|three_a))|(thrice&three_a);
        second=(y&one_b)|(twice&~(one_b|three_b))|(thrice&three_b);
    } else {
        first=a==1?y:(a==2?twice:thrice);
        second=b==1?y:(b==2?twice:thrice);
    }
}

// Disjoint canonical src/dst; n<=2^21; p has n+PF+U+2 entries.
// Padding is zero. Every live entry packs index | (a-1)<<21 | (b-1)<<23.
// Mode 0: fused small-integer products. Mode 1: shared addition chains.
// Mode 2: eagerly compute both multiples. Mode 3 also masks selections.
template<unsigned PF,unsigned U,unsigned Mode> inline void convolution(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    static_assert(Mode<=3 && U>0);
    if(!n)return;
    F prev=src[p[0]&conv_index_mask],older=0;
    F next=0,delayed=0,pending=0;
    dst[0]=prev;
    if(n==1)return;
    if constexpr(Mode)conv_prepare<(Mode>=2),Mode==3>(prev,conv_a(p[1]),n>2?conv_b(p[2]):1,next,delayed);
    F y;
    if constexpr(Mode)y=add(src[p[1]&conv_index_mask],next);
    else y=madd_small(prev,conv_a(p[1]),src[p[1]&conv_index_mask]);
    dst[1]=y;older=prev;prev=y;
    if(n==2)return;
    if constexpr(Mode) {
        pending=delayed;
        conv_prepare<(Mode>=2),Mode==3>(y,conv_a(p[2]),n>3?conv_b(p[3]):1,next,delayed);
    }
    size_t i=2;
    for(;i+U<=n;i+=U) {
        F gathered[U];uint32_t meta[U],future_a[U],future_b[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+(p[i+j+PF]&conv_index_mask),0,1);
            meta[j]=p[i+j];gathered[j]=src[meta[j]&conv_index_mask];
            if constexpr(Mode){future_a[j]=p[i+j+1];future_b[j]=p[i+j+2];}
        }
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            if constexpr(Mode) {
                y=add(add(gathered[j],next),pending);pending=delayed;
                conv_prepare<(Mode>=2),Mode==3>(y,conv_a(future_a[j]),conv_b(future_b[j]),next,delayed);
            } else {y=conv_madd(prev,conv_a(meta[j]),older,conv_b(meta[j]),gathered[j]);older=prev;prev=y;}
            dst[i+j]=y;
        }
    }
    for(;i<n;++i) {
        if constexpr(Mode) {
            y=add(add(src[p[i]&conv_index_mask],next),pending);pending=delayed;
            conv_prepare<(Mode>=2),Mode==3>(y,conv_a(p[i+1]),conv_b(p[i+2]),next,delayed);
        } else {y=conv_madd(prev,conv_a(p[i]),older,conv_b(p[i]),src[p[i]&conv_index_mask]);older=prev;prev=y;}
        dst[i]=y;
    }
}

// Compose two recurrence steps. Both outputs depend on the previous pair,
// so the processor can overlap their arithmetic. Offset work is independent
// of recurrence state. Coefficients grow only to 12 and 9; same reduction.
template<unsigned PF,unsigned U> inline void convolution_pairs(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    static_assert(U%2==0);
    F prev=0,older=0;size_t i=0;
    for(;i+U<=n;i+=U) {
        F gathered[U],offset[U/2];unsigned a[U],b[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+(p[i+j+PF]&conv_index_mask),0,1);
            gathered[j]=src[p[i+j]&conv_index_mask];a[j]=conv_a(p[i+j]);b[j]=conv_b(p[i+j]);
        }
        #pragma GCC unroll 32
        for(unsigned j=0;j<U;j+=2)offset[j/2]=madd_small(gathered[j],a[j+1],gathered[j+1]);
        #pragma GCC unroll 32
        for(unsigned j=0;j<U;j+=2) {
            const F first=conv_madd(prev,a[j],older,b[j],gathered[j]);
            const F second=conv_madd(prev,a[j+1]*a[j]+b[j+1],older,a[j+1]*b[j],offset[j/2]);
            dst[i+j]=first;dst[i+j+1]=second;older=first;prev=second;
        }
    }
    for(;i<n;++i){const F y=conv_madd(prev,conv_a(p[i]),older,conv_b(p[i]),src[p[i]&conv_index_mask]);dst[i]=y;older=prev;prev=y;}
}
}
