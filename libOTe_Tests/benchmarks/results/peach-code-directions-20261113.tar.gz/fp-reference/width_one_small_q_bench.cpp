// Reuse the archived benchmark's setup, reference, precode, and timing code
// without changing the source whose hashes identify that earlier campaign.
// The runner extracts everything preceding main into this include file.
#include "certified_convolution_shared.inc"

namespace fp128 {
template<unsigned Q> inline F small_q_add_step(F state,uint32_t meta,F input) {
    static_assert(Q==1 || Q==2);
    if constexpr(Q==1)return add_asm(state,input);
    else {
        const F extra=state&(F(0)-F(meta>>21));
        // Sum the selected double and input before one modular reduction.
        return sum_raw_asm(input,{state,0},{extra,0});
    }
}
template<unsigned Q,unsigned PF=256,unsigned U=16> inline void small_q_add_scan(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    if(!n)return;
    F state=src[p[0]&MASK21];dst[0]=state;size_t i=1;
    for(;i+U<=n;i+=U) {
        uint32_t meta[U];F gathered[U];
        #pragma GCC unroll 16
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+(p[i+PF+j]&MASK21),0,1);
            meta[j]=p[i+j];gathered[j]=src[meta[j]&MASK21];
        }
        #pragma GCC unroll 16
        for(unsigned j=0;j<U;++j)dst[i+j]=state=small_q_add_step<Q>(state,meta[j],gathered[j]);
    }
    for(;i<n;++i)dst[i]=state=small_q_add_step<Q>(state,p[i],src[p[i]&MASK21]);
}
}

template<unsigned Q,bool Addition=false> struct SmallQConfig {
    static constexpr unsigned width=1,q=Q;
    using Word=uint32_t;
    static const char* name() {
        if constexpr(Q==1)return "w1_q1_add";
        if constexpr(Q==2 && Addition)return "w1_q2_add";
        if constexpr(Q==2)return "w1_q2_mul";
        if constexpr(Q==4)return "w1_q4_mul";
        if constexpr(Q==8)return "w1_q8_mul";
        if constexpr(Q==16)return "w1_q16_mul";
        if constexpr(Q==32)return "w1_q32_mul";
        if constexpr(Q==64)return "w1_q64_mul";
        if constexpr(Q==128)return "w1_q128_mul";
    }
    static Word pack(uint32_t i,const std::array<unsigned,1>& c){return i|((c[0]-1)<<21);}
    static uint32_t index(Word p){return p&MASK21;}
    static unsigned coefficient(Word p,unsigned){return (p>>21)+1;}
    static void scan(const F* src,F* dst,const Word* p,size_t n) {
        if constexpr(Addition)fp128::small_q_add_scan<Q>(src,dst,p,n);
        else fp128::scan_scheduled<256,16>(src,dst,p,n);
    }
};
template<> struct CertifiedConfig<4>:SmallQConfig<1,true>{};
template<> struct CertifiedConfig<5>:SmallQConfig<2>{};
template<> struct CertifiedConfig<6>:SmallQConfig<2,true>{};
template<> struct CertifiedConfig<7>:SmallQConfig<4>{};
template<> struct CertifiedConfig<8>:SmallQConfig<8>{};
template<> struct CertifiedConfig<9>:SmallQConfig<16>{};
template<> struct CertifiedConfig<10>:SmallQConfig<32>{};
template<> struct CertifiedConfig<11>:SmallQConfig<64>{};
template<> struct CertifiedConfig<12>:SmallQConfig<128>{};

void small_q_arithmetic_test() {
    using boost::multiprecision::uint256_t;
    auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto check=[&](F x,F y,unsigned m) {
        if(big(fp128::small_q_add_step<2>(x,(m-1)<<21,y))!=(big(x)*m+big(y))%big(P))
            throw std::runtime_error("q2 addition integer oracle mismatch");
        if(big(fp128::small_q_add_step<1>(x,0,y))!=(big(x)+big(y))%big(P))
            throw std::runtime_error("q1 integer oracle mismatch");
        if(big(fp128::madd_small(x,m,y))!=(big(x)*m+big(y))%big(P))
            throw std::runtime_error("q2 multiplication integer oracle mismatch");
    };
    const F edges[]={0,1,158,159,(F(1)<<64)-1,F(1)<<64,P/2,P-2,P-1};
    for(F x:edges)for(F y:edges)for(unsigned m=1;m<=2;++m)check(x,y,m);
    Rng rng{20260923};
    for(unsigned i=0;i<100000;++i)check(rng.field(),rng.field(),unsigned(rng.below(2)+1));
}
template<int Id=0> void small_q_dispatch(int id,size_t k,int it,uint64_t seed,bool test) {
    if(id==Id){if(test)certified_test<Id>();certified_case<Id>(k,it,seed);}
    else if constexpr(Id<12)small_q_dispatch<Id+1>(id,k,it,seed,test);
    else throw std::runtime_error("invalid small-q case");
}
int main(int argc,char** argv) {
    try {
        for(const char* path:{"/tmp/prindal-addition-encoder-benchmark.lock","/tmp/bare-spin-benchmark.lock","/tmp/hypercat-benchmark.lock"}) {
            int fd=open(path,O_CREAT|O_RDWR,0600);if(fd<0||flock(fd,LOCK_EX|LOCK_NB))throw std::runtime_error(std::string("benchmark lock unavailable: ")+path);
        }
        size_t k=1<<20;int it=31,id=-1;uint64_t seed=20260923;bool test=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto val=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--case")id=std::stoi(val());else if(arg=="--iterations")it=std::stoi(val());else if(arg=="--seed")seed=std::stoull(val());
            else if(arg=="--k")k=std::stoull(val());else if(arg=="--test")test=true;else throw std::runtime_error("unknown option");
        }
        if(test){certified_arithmetic_test();small_q_arithmetic_test();k=256;it=1;}
        if(k<8||k%8||k>(1u<<20)||it<1||id< -1||id>12||id==3)throw std::runtime_error("invalid options");
        if(id>=0)small_q_dispatch(id,k,it,seed,test);
        else for(int j:{4,5,6,7,8,9,10,11,12,0,1,2})small_q_dispatch(j,k,it,seed,test);
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
