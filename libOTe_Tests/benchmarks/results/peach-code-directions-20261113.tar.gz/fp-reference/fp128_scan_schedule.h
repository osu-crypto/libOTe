#pragma once
#include "fp128_small.h"

namespace fp128 {
// Four explicit gathers preserve the established kernel structure.
// Require n>0 and at least PF+4 valid zero-padded metadata entries.
template<int PF> inline void scan_explicit(const F* __restrict src,F* __restrict dst,
                                 const uint32_t* __restrict p,size_t n) {
    F state=src[p[0]&((1u<<21)-1)];dst[0]=state;size_t i=1;
    for(;i+3<n;i+=4) {
        if constexpr(PF) {
            __builtin_prefetch(src+(p[i+PF]&((1u<<21)-1)),0,1);
            __builtin_prefetch(src+(p[i+PF+1]&((1u<<21)-1)),0,1);
            __builtin_prefetch(src+(p[i+PF+2]&((1u<<21)-1)),0,1);
            __builtin_prefetch(src+(p[i+PF+3]&((1u<<21)-1)),0,1);
        }
        const uint32_t p0=p[i],p1=p[i+1],p2=p[i+2],p3=p[i+3];
        const F x0=src[p0&((1u<<21)-1)],x1=src[p1&((1u<<21)-1)],x2=src[p2&((1u<<21)-1)],x3=src[p3&((1u<<21)-1)];
        dst[i]=state=fp128::madd_small(state,(p0>>21)+1,x0);
        dst[i+1]=state=fp128::madd_small(state,(p1>>21)+1,x1);
        dst[i+2]=state=fp128::madd_small(state,(p2>>21)+1,x2);
        dst[i+3]=state=fp128::madd_small(state,(p3>>21)+1,x3);
    }
    for(;i<n;++i)dst[i]=state=fp128::madd_small(state,(p[i]>>21)+1,src[p[i]&((1u<<21)-1)]);
}

// Allow any 128-bit residue as the running state. For m<=40 and canonical
// input, the integer high part is <=40. After folding, an overflow correction
// is <=159+6359, so it cannot overflow again. Canonicalization is needed only
// for the stored output and is independent of the next recurrence step.
inline F madd_relaxed(F x,uint32_t m,F input) {
    const F lo=F(uint64_t(x))*m+uint64_t(input);
    const F hi=F(uint64_t(x>>64))*m+uint64_t(input>>64)+(lo>>64);
    const F low=(hi<<64)|uint64_t(lo),correction=(hi>>64)*159;
    const F folded=low+correction;
    return folded+(F(159)&(F(0)-F(folded<low)));
}
inline F canonicalize(F x) {return x-(modulus&(F(0)-F(x>=modulus)));}

// Same fused arithmetic with a wider multiplier bound for composed pairs.
// m<=1600 makes the fold correction <=254400, within the same safe bounds.
inline F madd_pair(F x,uint32_t m,F input) {
    const F lo=F(uint64_t(x))*m+uint64_t(input);
    const F hi=F(uint64_t(x>>64))*m+uint64_t(input>>64)+(lo>>64);
    return add((hi<<64)|uint64_t(lo),(hi>>64)*159);
}
template<unsigned PF> inline void scan_pairs(
    const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    constexpr uint32_t mask=(1u<<21)-1;
    if(!n)return;
    F state=src[p[0]&mask];dst[0]=state;size_t i=1;
    for(;i+3<n;i+=4) {
        __builtin_prefetch(src+(p[i+PF]&mask),0,1);
        __builtin_prefetch(src+(p[i+PF+1]&mask),0,1);
        __builtin_prefetch(src+(p[i+PF+2]&mask),0,1);
        __builtin_prefetch(src+(p[i+PF+3]&mask),0,1);
        const uint32_t p0=p[i],p1=p[i+1],p2=p[i+2],p3=p[i+3];
        const F x0=src[p0&mask],x1=src[p1&mask],x2=src[p2&mask],x3=src[p3&mask];
        const uint32_t m0=(p0>>21)+1,m1=(p1>>21)+1,m2=(p2>>21)+1,m3=(p3>>21)+1;
        const F offset01=madd_small(x0,m1,x1),offset23=madd_small(x2,m3,x3);
        dst[i]=madd_small(state,m0,x0);
        dst[i+1]=state=madd_pair(state,m0*m1,offset01);
        dst[i+2]=madd_small(state,m2,x2);
        dst[i+3]=state=madd_pair(state,m2*m3,offset23);
    }
    for(;i<n;++i)dst[i]=state=madd_small(state,(p[i]>>21)+1,src[p[i]&mask]);
}

// Packed 21-bit index and coefficient-minus-one. Metadata needs PF+U
// zero-padded entries. Every padded index refers to the valid src[0].
template<unsigned PF,unsigned U,unsigned Hint=1,bool Relaxed=false> inline void scan_scheduled(
    const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    constexpr uint32_t mask=(1u<<21)-1;
    if(!n)return;
    F state=src[p[0]&mask];dst[0]=state;size_t i=1;
    for(;i+U<=n;i+=U) {
        uint32_t metadata[U];F gathered[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            if constexpr(PF)__builtin_prefetch(src+(p[i+PF+j]&mask),0,Hint);
            metadata[j]=p[i+j];gathered[j]=src[metadata[j]&mask];
        }
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            if constexpr(Relaxed) {
                state=madd_relaxed(state,(metadata[j]>>21)+1,gathered[j]);dst[i+j]=canonicalize(state);
            } else dst[i+j]=state=madd_small(state,(metadata[j]>>21)+1,gathered[j]);
        }
    }
    for(;i<n;++i) {
        if constexpr(Relaxed) {state=madd_relaxed(state,(p[i]>>21)+1,src[p[i]&mask]);dst[i]=canonicalize(state);}
        else dst[i]=state=madd_small(state,(p[i]>>21)+1,src[p[i]&mask]);
    }
}

// Gather an entire fixed-size tile before its serial arithmetic. This exposes
// more independent loads, at the cost of a bounded stack staging area.
template<unsigned Tile,unsigned PF> inline void scan_tiled(
    const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    constexpr uint32_t mask=(1u<<21)-1;
    if(!n)return;
    F state=src[p[0]&mask];dst[0]=state;size_t i=1;
    F gathered[Tile];uint32_t coeff[Tile];
    for(;i+Tile<=n;i+=Tile) {
        for(unsigned j=0;j<Tile;++j) {
            if constexpr(PF)__builtin_prefetch(src+(p[i+PF+j]&mask),0,1);
            const uint32_t v=p[i+j];gathered[j]=src[v&mask];coeff[j]=(v>>21)+1;
        }
        #pragma GCC unroll 4
        for(unsigned j=0;j<Tile;++j)dst[i+j]=state=madd_small(state,coeff[j],gathered[j]);
    }
    for(;i<n;++i)dst[i]=state=madd_small(state,(p[i]>>21)+1,src[p[i]&mask]);
}
}
