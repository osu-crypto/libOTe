#pragma once
#include "fp128_mul.h"

namespace fp128 {
// Dedicated 128-by-small-integer product. Canonical x, 1 <= m <= 2048.
// The high word is <=2047, so the fold correction is at most325473.
inline F mul_small(F x, uint32_t m) {
    const F lo = F(uint64_t(x))*m;
    const F hi = F(uint64_t(x>>64))*m+(lo>>64);
    const F folded = (hi<<64)|uint64_t(lo);
    return add(folded, (hi>>64)*159);
}

// Canonical x/input, 1 <= m <= 2048. Fuse before reduction; high <=2048.
inline F madd_small(F x, uint32_t m, F input) {
    const F lo = F(uint64_t(x))*m+uint64_t(input);
    const F hi = F(uint64_t(x>>64))*m+uint64_t(input>>64)+(lo>>64);
    return add((hi<<64)|uint64_t(lo), (hi>>64)*159);
}

inline F msub_small(F x, uint32_t m, F input) {
    const F lo = F(uint64_t(x))*m;
    const F hi = F(uint64_t(x>>64))*m+(lo>>64);
    const F product_low = (hi<<64)|uint64_t(lo);
    const F difference = input-product_low;
    const F correction = ((hi>>64)+F(input<product_low))*159;
    F result = difference-correction;
    // Borrow across 2^128 subtracts159 because 2^128 ==159 modulo p.
    result -= F(159)&(F(0)-F(difference<correction));
    return result-(modulus&(F(0)-F(result>=modulus)));
}

template<unsigned M> inline F multiply_constant(F x) {
    static_assert(M>=1 && M<=40);
    if constexpr(M==1) return x;
    else {
        const F half=multiply_constant<M/2>(x);
        const F doubled=add(half,half);
        if constexpr(M&1) return add(doubled,x);
        else return doubled;
    }
}

template<unsigned Max> inline F mul_add_chain(F x, uint32_t m) {
    // Every chain is instantiated and unrolled at compile time. The switch
    // measures actual per-coefficient dispatch, not a variable bit loop.
    #define SMALL_CASE(M) case M: return multiply_constant<M>(x)
    switch(m) {
        SMALL_CASE(1); SMALL_CASE(2); SMALL_CASE(3); SMALL_CASE(4);
        SMALL_CASE(5); SMALL_CASE(6); SMALL_CASE(7); SMALL_CASE(8);
        SMALL_CASE(9); SMALL_CASE(10); SMALL_CASE(11); SMALL_CASE(12);
        SMALL_CASE(13); SMALL_CASE(14); SMALL_CASE(15); SMALL_CASE(16);
        SMALL_CASE(17); SMALL_CASE(18); SMALL_CASE(19); SMALL_CASE(20);
        default: break;
    }
    if constexpr(Max>20) {
        switch(m) {
            SMALL_CASE(21); SMALL_CASE(22); SMALL_CASE(23); SMALL_CASE(24);
            SMALL_CASE(25); SMALL_CASE(26); SMALL_CASE(27); SMALL_CASE(28);
            SMALL_CASE(29); SMALL_CASE(30); SMALL_CASE(31); SMALL_CASE(32);
            SMALL_CASE(33); SMALL_CASE(34); SMALL_CASE(35); SMALL_CASE(36);
            SMALL_CASE(37); SMALL_CASE(38); SMALL_CASE(39); SMALL_CASE(40);
            default: __builtin_unreachable();
        }
    } else __builtin_unreachable();
    #undef SMALL_CASE
}
}
