#pragma once
#include <type_traits>
#include "fp128_convolution_compact.h"

namespace fp128 {
// The coefficient ranges are 1..QA and 1..QB; unused encodings are never
// sampled. Index width is fixed at 21. Force64 isolates layout overhead.
template<unsigned QA,unsigned ABits,unsigned QB=QA,unsigned BBits=ABits,bool Force64=false>
struct ConvolutionAlphabet {
    static_assert(QA>=2 && QB>=2 && QA<=(1u<<ABits) && QB<=(1u<<BBits));
    static_assert(ABits<=21 && BBits<=21 && 21+ABits+BBits<=63);
    using Word=std::conditional_t<(21+ABits+BBits<=32 && !Force64),uint32_t,uint64_t>;
    static constexpr unsigned qa=QA,qb=QB;
    static constexpr Word amask=(Word(1)<<ABits)-1,bmask=(Word(1)<<BBits)-1;
    static uint32_t index(Word p){return uint32_t(p&conv_index_mask);}
    static unsigned a(Word p){return unsigned((p>>21)&amask)+1;}
    static unsigned b(Word p){return unsigned((p>>(21+ABits))&bmask)+1;}
    static Word pack(uint32_t index,unsigned a,unsigned b){return Word(index)|(Word(a-1)<<21)|(Word(b-1)<<(21+ABits));}
};

struct ConvolutionFull32 {
    struct Word {uint32_t index=0,a_minus_one=0,b_minus_one=0;};
    static_assert(sizeof(Word)==12);
    static constexpr unsigned qa=UINT32_MAX,qb=UINT32_MAX;
    static uint32_t index(Word p){return p.index;}
    static unsigned a(Word p){return p.a_minus_one+1;}
    static unsigned b(Word p){return p.b_minus_one+1;}
    static Word pack(uint32_t index,unsigned a,unsigned b){return {index,a-1,b-1};}
};

// q32 earns a certified margin improvement without widening metadata.
// Keep the wider layout for distance/margin research, not as the default.
using CompactConvolutionAlphabet=ConvolutionAlphabet<32,5>;
using DefaultConvolutionAlphabet=CompactConvolutionAlphabet;
using WideConvolutionAlphabet=ConvolutionAlphabet<(1u<<21),21>;

// Same direct two-tap mulx kernel, with compile-time metadata layout.
// Input/output must be disjoint canonical buffers. n<=2^21. Metadata has
// n+PF+U zero-padded entries, each live index < n.
template<class Alphabet=DefaultConvolutionAlphabet,unsigned PF=256,unsigned U=4> inline void convolution_alphabet(
        const F* __restrict src,F* __restrict dst,const typename Alphabet::Word* __restrict p,size_t n) {
    F prev=0,older=0;size_t i=0;
    for(;i+U<=n;i+=U) {
        __m128i gathered[U];unsigned a[U],b[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+Alphabet::index(p[i+j+PF]),0,1);
            gathered[j]=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+Alphabet::index(p[i+j])));
            a[j]=Alphabet::a(p[i+j]);b[j]=Alphabet::b(p[i+j]);
        }
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            const F out=conv_madd_mulx(prev,a[j],older,b[j],gathered[j]);older=prev;prev=out;dst[i+j]=out;
        }
    }
    for(;i<n;++i) {
        const __m128i input=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+Alphabet::index(p[i])));
        const F out=conv_madd_mulx(prev,Alphabet::a(p[i]),older,Alphabet::b(p[i]),input);older=prev;prev=out;dst[i]=out;
    }
}
}
