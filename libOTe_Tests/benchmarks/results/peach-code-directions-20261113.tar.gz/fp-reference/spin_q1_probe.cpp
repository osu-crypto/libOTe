// Isolated scan diagnostics; these are not complete encoder measurements.
// Build generates this include by taking width_one_small_q_bench.cpp up
// to its main function. The archived source and binary remain unchanged.
#include "width_one_small_q_probe_shared.inc"

template<bool Xor> __attribute__((noinline)) void routed_binary_probe(
        const F* __restrict src,F* __restrict dst,
        const uint32_t* __restrict p,size_t n) {
    F state=src[p[0]&MASK21];dst[0]=state;size_t i=1;
    for(;i+16<=n;i+=16) {
        F gathered[16];
        #pragma GCC unroll 16
        for(unsigned j=0;j<16;++j) {
            __builtin_prefetch(src+(p[i+256+j]&MASK21),0,1);
            gathered[j]=src[p[i+j]&MASK21];
        }
        #pragma GCC unroll 16
        for(unsigned j=0;j<16;++j) {
            if constexpr(Xor) dst[i+j]=state^=gathered[j];
            else dst[i+j]=gathered[j];
        }
    }
    for(;i<n;++i) {
        if constexpr(Xor) dst[i]=state^=src[p[i]&MASK21];
        else dst[i]=src[p[i]&MASK21];
    }
}

template<unsigned Mode,unsigned LogK=20> void probe(unsigned iterations) {
    constexpr size_t n=size_t(1)<<(LogK+1);
    Rng rng{20260923};std::vector<F> input(n),output(n),expected(n);
    for(auto& x:input)x=rng.field();
    auto meta=certified_setup<4>(n,20260923);
    auto& p=meta[0];
    if constexpr(Mode==1)for(size_t i=0;i<n;++i)p[i]=uint32_t(i);
    auto run=[&] {
        if constexpr(Mode<2)fp128::small_q_add_scan<1>(input.data(),output.data(),p.data(),n);
        else routed_binary_probe<Mode==2>(input.data(),output.data(),p.data(),n);
    };
    F state=0;
    for(size_t i=0;i<n;++i) {
        const F value=input[p[i]&MASK21];
        if constexpr(Mode<2)expected[i]=state=ref_add(state,value);
        else if constexpr(Mode==2)expected[i]=state^=value;
        else expected[i]=value;
    }
    run();if(output!=expected)throw std::runtime_error("probe reference mismatch");
    for(unsigned j=0;j<3;++j)run();
    std::vector<double> samples; samples.reserve(iterations);
    volatile uint64_t sink=0;
    for(unsigned j=0;j<iterations;++j) {
        const auto start=Clock::now();run();const auto end=Clock::now();
        samples.push_back(ms(start,end));sink=uint64_t(output[(j*997)%n]);
    }
    (void)sink;
    if(output!=expected)throw std::runtime_error("timed probe reference mismatch");
    const char* names[]={"fp_random","fp_identity","xor_random","gather_only"};
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"mode\":\""<<names[Mode]<<"\",\"n\":"<<n<<",\"validated\":true";
    print_stat("time_ms",samples);std::cout<<"}\n";
}

template<unsigned LogK> void dispatch_probe(unsigned mode) {
    if(mode==0)probe<0,LogK>(101);else if(mode==1)probe<1,LogK>(101);
    else if(mode==2)probe<2,LogK>(101);else if(mode==3)probe<3,LogK>(101);
    else throw std::runtime_error("invalid mode");
}

int main(int argc,char** argv) {
    try {
        for(const char* path:{"/tmp/prindal-addition-encoder-benchmark.lock","/tmp/bare-spin-benchmark.lock","/tmp/hypercat-benchmark.lock"}) {
            const int fd=open(path,O_CREAT|O_RDWR,0600);
            if(fd<0||flock(fd,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        }
        if(argc<2||argc>3)throw std::runtime_error("expected mode 0..3 [log2(k)=18|20]");
        const unsigned mode=unsigned(std::stoul(argv[1]));
        const unsigned logk=argc==3?unsigned(std::stoul(argv[2])):20;
        if(logk==18)dispatch_probe<18>(mode);
        else if(logk==20)dispatch_probe<20>(mode);
        else throw std::runtime_error("unsupported message length");
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
