// Compile separately with -O3 -march=native -S to inspect isolated kernels.
#include "fp128_mul.h"
extern "C" __attribute__((noinline)) fp128::F probe_mul(fp128::F a,fp128::F b) {
    return fp128::mul_bmi2(a,b);
}
extern "C" __attribute__((noinline)) fp128::F probe_native(fp128::F a,fp128::F b) {
    return fp128::mul(a,b);
}
extern "C" __attribute__((noinline)) fp128::F probe_montgomery(fp128::F a,fp128::F b) {
    return fp128::montgomery(a,b);
}
