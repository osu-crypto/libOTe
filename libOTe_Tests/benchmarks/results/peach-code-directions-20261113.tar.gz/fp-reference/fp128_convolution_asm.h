#pragma once
#include "fp128_convolution.h"

namespace fp128 {
// Canonical a,b. Since a+159 cannot overflow, the carry from adding b to
// a+159 says exactly whether a+b >= p. Undo 159 only when there is no carry.
// Explicit asm prevents GCC from replacing masks with data-dependent jumps.
inline F add_asm(F a,F b) {
    uint64_t lo=a,hi=a>>64,mask;
    asm("addq $159,%[lo]\n\tadcq $0,%[hi]\n\t"
        "addq %[bl],%[lo]\n\tadcq %[bh],%[hi]\n\t"
        "sbbq %[mask],%[mask]\n\tnotq %[mask]\n\tandq $159,%[mask]\n\t"
        "subq %[mask],%[lo]\n\tsbbq $0,%[hi]"
        : [lo] "+&r"(lo),[hi] "+&r"(hi),[mask] "=&r"(mask)
        : [bl] "r"(uint64_t(b)),[bh] "r"(uint64_t(b>>64)) : "cc");
    return (F(hi)<<64)|lo;
}

// low may be noncanonical; correction<=3339. Add correction+159 first.
// Its carry says exactly whether low+correction >= p. Undo 159 otherwise.
inline F fold_small_asm(F low,uint64_t correction) {
    uint64_t lo=low,hi=low>>64,mask;
    asm("addq %[c],%[lo]\n\tadcq $0,%[hi]\n\tsbbq %[mask],%[mask]\n\t"
        "notq %[mask]\n\tandq $159,%[mask]\n\tsubq %[mask],%[lo]\n\tsbbq $0,%[hi]"
        : [lo] "+&r"(lo),[hi] "+&r"(hi),[mask] "=&r"(mask)
        : [c] "r"(correction+159) : "cc");
    return (F(hi)<<64)|lo;
}
inline F select3_asm(F one,F two,F three,unsigned coefficient) {
    uint64_t lo=one,hi=one>>64;
    asm("cmpl $2,%[c]\n\tcmoveq %[tl],%[lo]\n\tcmoveq %[th],%[hi]\n\t"
        "cmpl $3,%[c]\n\tcmoveq %[rl],%[lo]\n\tcmoveq %[rh],%[hi]"
        : [lo] "+&r"(lo),[hi] "+&r"(hi)
        : [c] "r"(coefficient),[tl] "r"(uint64_t(two)),[th] "r"(uint64_t(two>>64)),
          [rl] "r"(uint64_t(three)),[rh] "r"(uint64_t(three>>64)) : "cc");
    return (F(hi)<<64)|lo;
}
inline F conv_madd_asm(F x,unsigned a,F y,unsigned b,F input) {
    const F lo=F(uint64_t(x))*a+F(uint64_t(y))*b+uint64_t(input);
    const F hi=F(uint64_t(x>>64))*a+F(uint64_t(y>>64))*b+uint64_t(input>>64)+(lo>>64);
    return fold_small_asm((hi<<64)|uint64_t(lo),uint64_t(hi>>64)*159);
}

struct ConvRaw { F low;uint64_t high; };
inline ConvRaw raw_add_asm(ConvRaw x,F y) {
    uint64_t lo=x.low,hi=x.low>>64,excess=x.high;
    asm("addq %[yl],%[lo]\n\tadcq %[yh],%[hi]\n\tadcq $0,%[excess]"
        : [lo] "+&r"(lo),[hi] "+&r"(hi),[excess] "+&r"(excess)
        : [yl] "r"(uint64_t(y)),[yh] "r"(uint64_t(y>>64)) : "cc");
    return {(F(hi)<<64)|lo,excess};
}
inline ConvRaw select_raw_asm(F one,ConvRaw two,ConvRaw three,unsigned c) {
    uint64_t high=0;
    asm("cmpl $2,%[c]\n\tcmoveq %[two],%[out]\n\t"
        "cmpl $3,%[c]\n\tcmoveq %[three],%[out]"
        : [out] "+&r"(high) : [c] "r"(c),[two] "r"(two.high),[three] "r"(three.high) : "cc");
    return {select3_asm(one,two.low,three.low,c),high};
}
inline F sum_raw_asm(F input,ConvRaw x,ConvRaw y) {
    const ConvRaw first=raw_add_asm({input,x.high+y.high},x.low);
    const ConvRaw second=raw_add_asm(first,y.low);
    return fold_small_asm(second.low,second.high*159);
}

// Kind 0: direct fused products with asm reduction.
// Kind 1: eager shared doubles/triples with asm add and selection.
// Kind 2: shared unreduced doubles/triples, one modular reduction per output.
template<unsigned PF,unsigned U,unsigned Kind> inline void convolution_asm(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    static_assert(Kind<=2);
    F prev=0,older=0,next=0,pending=0,delayed=0;size_t i=0;
    ConvRaw raw_next{0,0},raw_pending{0,0},raw_delayed{0,0};
    for(;i+U<=n;i+=U) {
        F gathered[U];uint32_t meta[U],a[U],b[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+(p[i+j+PF]&conv_index_mask),0,1);
            meta[j]=p[i+j];gathered[j]=src[meta[j]&conv_index_mask];
            if constexpr(Kind){a[j]=conv_a(p[i+j+1]);b[j]=conv_b(p[i+j+2]);}
        }
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            F out;
            if constexpr(Kind==2) {
                out=sum_raw_asm(gathered[j],raw_next,raw_pending);raw_pending=raw_delayed;
                const ConvRaw two=raw_add_asm({out,0},out),three=raw_add_asm(two,out);
                raw_next=select_raw_asm(out,two,three,a[j]);raw_delayed=select_raw_asm(out,two,three,b[j]);
            } else if constexpr(Kind==1) {
                out=add_asm(add_asm(gathered[j],next),pending);pending=delayed;
                const F two=add_asm(out,out),three=add_asm(two,out);
                next=select3_asm(out,two,three,a[j]);delayed=select3_asm(out,two,three,b[j]);
            } else {out=conv_madd_asm(prev,conv_a(meta[j]),older,conv_b(meta[j]),gathered[j]);older=prev;prev=out;}
            dst[i+j]=out;
        }
    }
    for(;i<n;++i) {
        F out;
        if constexpr(Kind==2) {
            out=sum_raw_asm(src[p[i]&conv_index_mask],raw_next,raw_pending);raw_pending=raw_delayed;
            const ConvRaw two=raw_add_asm({out,0},out),three=raw_add_asm(two,out);
            raw_next=select_raw_asm(out,two,three,conv_a(p[i+1]));raw_delayed=select_raw_asm(out,two,three,conv_b(p[i+2]));
        } else if constexpr(Kind==1) {
            out=add_asm(add_asm(src[p[i]&conv_index_mask],next),pending);pending=delayed;
            const F two=add_asm(out,out),three=add_asm(two,out);
            next=select3_asm(out,two,three,conv_a(p[i+1]));delayed=select3_asm(out,two,three,conv_b(p[i+2]));
        } else {out=conv_madd_asm(prev,conv_a(p[i]),older,conv_b(p[i]),src[p[i]&conv_index_mask]);older=prev;prev=out;}
        dst[i]=out;
    }
}
}
