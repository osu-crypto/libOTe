#pragma once
#include "fp128_convolution_asm.h"

namespace fp128 {
// Exact two-tap integer sum in three limbs. This is 128-by-small-integer
// arithmetic, not a general field multiplier. BMI2 mulx leaves carry flags
// intact and exposes the four limb products directly to the scheduler.
inline F conv_madd_mulx(F x,unsigned a,F y,unsigned b,__m128i input) {
    uint64_t lo,mid,high,t0,t1,cross,aa=a;
    asm(
        "mulxq %[xl],%[lo],%[cross]\n\tmulxq %[xh],%[mid],%[high]\n\t"
        "addq %[cross],%[mid]\n\tadcq $0,%[high]\n\t"
        "movq %[b],%%rdx\n\tmulxq %[yl],%[t0],%[t1]\n\t"
        "addq %[t0],%[lo]\n\tadcq %[t1],%[mid]\n\tadcq $0,%[high]\n\t"
        "mulxq %[yh],%[t0],%[t1]\n\taddq %[t0],%[mid]\n\tadcq %[t1],%[high]\n\t"
        "vmovq %[input],%[t0]\n\tvpextrq $1,%[input],%[t1]\n\t"
        "addq %[t0],%[lo]\n\tadcq %[t1],%[mid]\n\tadcq $0,%[high]\n\t"
        "imulq $159,%[high],%[high]\n\taddq $159,%[high]\n\t"
        "addq %[high],%[lo]\n\tadcq $0,%[mid]\n\tsbbq %[high],%[high]\n\t"
        "notq %[high]\n\tandq $159,%[high]\n\tsubq %[high],%[lo]\n\tsbbq $0,%[mid]"
        : [lo] "=&r"(lo),[mid] "=&r"(mid),[high] "=&r"(high),[t0] "=&r"(t0),[t1] "=&r"(t1),
          [cross] "=&r"(cross),[a] "+&d"(aa)
        : [xl] "rm"(uint64_t(x)),[xh] "rm"(uint64_t(x>>64)),[yl] "rm"(uint64_t(y)),[yh] "rm"(uint64_t(y>>64)),
          [b] "rm"(uint64_t(b)),[input] "x"(input) : "cc");
    return (F(mid)<<64)|lo;
}

template<unsigned PF,unsigned U> inline void convolution_mulx(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    F prev=0,older=0;size_t i=0;
    for(;i+U<=n;i+=U) {
        __m128i gathered[U];unsigned a[U],b[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+(p[i+j+PF]&conv_index_mask),0,1);
            gathered[j]=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+(p[i+j]&conv_index_mask)));
            a[j]=conv_a(p[i+j]);b[j]=conv_b(p[i+j]);
        }
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            const F out=conv_madd_mulx(prev,a[j],older,b[j],gathered[j]);older=prev;prev=out;dst[i+j]=out;
        }
    }
    for(;i<n;++i) {
        const __m128i input=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+(p[i]&conv_index_mask)));
        const F out=conv_madd_mulx(prev,conv_a(p[i]),older,conv_b(p[i]),input);older=prev;prev=out;dst[i]=out;
    }
}

struct CompactState {uint64_t c0=0,c1=0,d0=0,d1=0,tag=0;};

// tag bits 0..2 hold combined's excess, bits 3..4 delayed's excess.
// The entire step is one asm block, allowing consumed state registers to
// become result registers. All field data stays in registers inside it.
inline __m128i compact_step_asm(__m128i input,CompactState& s,unsigned a,unsigned b) {
    uint64_t t0,t1,t2,t3,t4,th,ah;__m128i output;
    asm(
        "vmovq %[input],%[t0]\n\tvpextrq $1,%[input],%[t1]\n\t"
        "movq %[tag],%[t2]\n\tandq $7,%[t2]\n\tshrq $3,%[tag]\n\t"
        "addq %[t0],%[c0]\n\tadcq %[t1],%[c1]\n\tadcq $0,%[t2]\n\t"
        "imulq $159,%[t2],%[t2]\n\taddq $159,%[t2]\n\t"
        "addq %[t2],%[c0]\n\tadcq $0,%[c1]\n\tsbbq %[t2],%[t2]\n\t"
        "notq %[t2]\n\tandq $159,%[t2]\n\tsubq %[t2],%[c0]\n\tsbbq $0,%[c1]\n\t"
        "vmovq %[c0],%[output]\n\tvpinsrq $1,%[c1],%[output],%[output]\n\t"
        // Raw 2y and 3y, sharing the double.
        "movq %[c0],%[t0]\n\tmovq %[c1],%[t1]\n\txorq %[t2],%[t2]\n\t"
        "addq %[c0],%[t0]\n\tadcq %[c1],%[t1]\n\tadcq $0,%[t2]\n\t"
        "movq %[t0],%[t3]\n\tmovq %[t1],%[t4]\n\tmovq %[t2],%[th]\n\t"
        "addq %[c0],%[t3]\n\tadcq %[c1],%[t4]\n\tadcq $0,%[th]\n\t"
        // Reuse combined's low registers for a*y, then add old delayed.
        "xorq %[ah],%[ah]\n\tcmpl $2,%[a]\n\t"
        "cmoveq %[t0],%[c0]\n\tcmoveq %[t1],%[c1]\n\tcmoveq %[t2],%[ah]\n\t"
        "cmpl $3,%[a]\n\tcmoveq %[t3],%[c0]\n\tcmoveq %[t4],%[c1]\n\tcmoveq %[th],%[ah]\n\t"
        "addq %[tag],%[ah]\n\taddq %[d0],%[c0]\n\tadcq %[d1],%[c1]\n\tadcq $0,%[ah]\n\t"
        // Reuse consumed delayed registers for b*y.
        "vmovq %[output],%[d0]\n\tvpextrq $1,%[output],%[d1]\n\txorq %[tag],%[tag]\n\t"
        "cmpl $2,%[b]\n\tcmoveq %[t0],%[d0]\n\tcmoveq %[t1],%[d1]\n\tcmoveq %[t2],%[tag]\n\t"
        "cmpl $3,%[b]\n\tcmoveq %[t3],%[d0]\n\tcmoveq %[t4],%[d1]\n\tcmoveq %[th],%[tag]\n\t"
        "shlq $3,%[tag]\n\torq %[ah],%[tag]"
        : [c0] "+&r"(s.c0),[c1] "+&r"(s.c1),[d0] "+&r"(s.d0),[d1] "+&r"(s.d1),[tag] "+&r"(s.tag),
          [t0] "=&r"(t0),[t1] "=&r"(t1),[t2] "=&r"(t2),[t3] "=&r"(t3),[t4] "=&r"(t4),
          [th] "=&r"(th),[ah] "=&r"(ah),[output] "=&x"(output)
        : [input] "x"(input),[a] "rm"(a),[b] "rm"(b) : "cc");
    return output;
}

template<unsigned PF,unsigned U> inline void convolution_compact_asm(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    CompactState state;size_t i=0;
    for(;i+U<=n;i+=U) {
        __m128i gathered[U];unsigned a[U],b[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+(p[i+j+PF]&conv_index_mask),0,1);
            gathered[j]=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+(p[i+j]&conv_index_mask)));
            a[j]=conv_a(p[i+j+1]);b[j]=conv_b(p[i+j+2]);
        }
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            const __m128i output=compact_step_asm(gathered[j],state,a[j],b[j]);
            _mm_storeu_si128(reinterpret_cast<__m128i*>(dst+i+j),output);
        }
    }
    for(;i<n;++i) {
        const __m128i input=_mm_loadu_si128(reinterpret_cast<const __m128i*>(src+(p[i]&conv_index_mask)));
        _mm_storeu_si128(reinterpret_cast<__m128i*>(dst+i),compact_step_asm(input,state,conv_a(p[i+1]),conv_b(p[i+2])));
    }
}

// Before output i, combined = a_i*y_(i-1)+b_i*y_(i-2), and
// delayed = b_(i+1)*y_(i-1), as exact nonnegative integers. Combining
// the next two feedback terms early removes one whole pending value.
// combined < 6p, delayed < 3p; the reduction excess remains at most 6.
template<unsigned PF,unsigned U> inline void convolution_compact(
        const F* __restrict src,F* __restrict dst,const uint32_t* __restrict p,size_t n) {
    ConvRaw combined{0,0},delayed{0,0};size_t i=0;
    for(;i+U<=n;i+=U) {
        F gathered[U];unsigned a[U],b[U];
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            __builtin_prefetch(src+(p[i+j+PF]&conv_index_mask),0,1);
            gathered[j]=src[p[i+j]&conv_index_mask];
            a[j]=conv_a(p[i+j+1]);b[j]=conv_b(p[i+j+2]);
        }
        #pragma GCC unroll 64
        for(unsigned j=0;j<U;++j) {
            const ConvRaw value=raw_add_asm(combined,gathered[j]);
            const F out=fold_small_asm(value.low,value.high*159);
            const ConvRaw two=raw_add_asm({out,0},out),three=raw_add_asm(two,out);
            ConvRaw first=select_raw_asm(out,two,three,a[j]);
            first.high+=delayed.high;
            combined=raw_add_asm(first,delayed.low);
            delayed=select_raw_asm(out,two,three,b[j]);
            dst[i+j]=out;
        }
    }
    for(;i<n;++i) {
        const ConvRaw value=raw_add_asm(combined,src[p[i]&conv_index_mask]);
        const F out=fold_small_asm(value.low,value.high*159);
        const ConvRaw two=raw_add_asm({out,0},out),three=raw_add_asm(two,out);
        ConvRaw first=select_raw_asm(out,two,three,conv_a(p[i+1]));
        first.high+=delayed.high;
        combined=raw_add_asm(first,delayed.low);
        delayed=select_raw_asm(out,two,three,conv_b(p[i+2]));
        dst[i]=out;
    }
}
}
