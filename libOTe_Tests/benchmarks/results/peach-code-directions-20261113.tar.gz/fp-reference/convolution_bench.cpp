#define SCAN_SCHEDULE_NO_MAIN
#include "scan_schedule_bench.cpp"
#include "fp128_convolution.h"
#include "fp128_convolution_asm.h"
#include "fp128_convolution_compact.h"

const char* conv_names[]={"q40_pf256_u16","fused_pf128_u4","fused_pf256_u4",
    "fused_pf128_u16","fused_pf256_u16","shared_pf128_u4","shared_pf256_u4",
    "shared_pf256_u16","eager_pf256_u4","eager_pf256_u16","masked_pf256_u4",
    "masked_pf256_u16","pairs_pf256_u4","pairs_pf256_u16",
    "asm_fused_pf256_u4","asm_fused_pf256_u16","asm_shared_pf128_u4",
    "asm_shared_pf256_u4","asm_shared_pf256_u16","asm_raw_pf128_u4",
    "asm_raw_pf256_u4","asm_raw_pf256_u16","asm_raw_pf256_u1","asm_raw_pf256_u2",
    "asm_raw_pf128_u2","compact_pf128_u4","compact_pf256_u4","compact_pf256_u2",
    "compact_pf256_u8","compact_pf256_u16","compact_asm_pf128_u4","compact_asm_pf256_u4",
    "compact_asm_pf256_u2","compact_asm_pf256_u8","compact_asm_pf256_u16",
    "mulx_pf128_u4","mulx_pf256_u4","mulx_pf256_u8","mulx_pf256_u16"};
constexpr int CONV_CASES=sizeof(conv_names)/sizeof(conv_names[0]);

template<int Id> void conv_scan(const F* src,F* dst,const uint32_t* p,size_t n) {
    if constexpr(Id==0)fp128::scan_scheduled<256,16>(src,dst,p,n);
    if constexpr(Id==1)fp128::convolution<128,4,0>(src,dst,p,n);
    if constexpr(Id==2)fp128::convolution<256,4,0>(src,dst,p,n);
    if constexpr(Id==3)fp128::convolution<128,16,0>(src,dst,p,n);
    if constexpr(Id==4)fp128::convolution<256,16,0>(src,dst,p,n);
    if constexpr(Id==5)fp128::convolution<128,4,1>(src,dst,p,n);
    if constexpr(Id==6)fp128::convolution<256,4,1>(src,dst,p,n);
    if constexpr(Id==7)fp128::convolution<256,16,1>(src,dst,p,n);
    if constexpr(Id==8)fp128::convolution<256,4,2>(src,dst,p,n);
    if constexpr(Id==9)fp128::convolution<256,16,2>(src,dst,p,n);
    if constexpr(Id==10)fp128::convolution<256,4,3>(src,dst,p,n);
    if constexpr(Id==11)fp128::convolution<256,16,3>(src,dst,p,n);
    if constexpr(Id==12)fp128::convolution_pairs<256,4>(src,dst,p,n);
    if constexpr(Id==13)fp128::convolution_pairs<256,16>(src,dst,p,n);
    if constexpr(Id==14)fp128::convolution_asm<256,4,0>(src,dst,p,n);
    if constexpr(Id==15)fp128::convolution_asm<256,16,0>(src,dst,p,n);
    if constexpr(Id==16)fp128::convolution_asm<128,4,1>(src,dst,p,n);
    if constexpr(Id==17)fp128::convolution_asm<256,4,1>(src,dst,p,n);
    if constexpr(Id==18)fp128::convolution_asm<256,16,1>(src,dst,p,n);
    if constexpr(Id==19)fp128::convolution_asm<128,4,2>(src,dst,p,n);
    if constexpr(Id==20)fp128::convolution_asm<256,4,2>(src,dst,p,n);
    if constexpr(Id==21)fp128::convolution_asm<256,16,2>(src,dst,p,n);
    if constexpr(Id==22)fp128::convolution_asm<256,1,2>(src,dst,p,n);
    if constexpr(Id==23)fp128::convolution_asm<256,2,2>(src,dst,p,n);
    if constexpr(Id==24)fp128::convolution_asm<128,2,2>(src,dst,p,n);
    if constexpr(Id==25)fp128::convolution_compact<128,4>(src,dst,p,n);
    if constexpr(Id==26)fp128::convolution_compact<256,4>(src,dst,p,n);
    if constexpr(Id==27)fp128::convolution_compact<256,2>(src,dst,p,n);
    if constexpr(Id==28)fp128::convolution_compact<256,8>(src,dst,p,n);
    if constexpr(Id==29)fp128::convolution_compact<256,16>(src,dst,p,n);
    if constexpr(Id==30)fp128::convolution_compact_asm<128,4>(src,dst,p,n);
    if constexpr(Id==31)fp128::convolution_compact_asm<256,4>(src,dst,p,n);
    if constexpr(Id==32)fp128::convolution_compact_asm<256,2>(src,dst,p,n);
    if constexpr(Id==33)fp128::convolution_compact_asm<256,8>(src,dst,p,n);
    if constexpr(Id==34)fp128::convolution_compact_asm<256,16>(src,dst,p,n);
    if constexpr(Id==35)fp128::convolution_mulx<128,4>(src,dst,p,n);
    if constexpr(Id==36)fp128::convolution_mulx<256,4>(src,dst,p,n);
    if constexpr(Id==37)fp128::convolution_mulx<256,8>(src,dst,p,n);
    if constexpr(Id==38)fp128::convolution_mulx<256,16>(src,dst,p,n);
}
void conv_reference(const F* src,F* dst,const uint32_t* p,size_t n,bool scalar) {
    F prev=0,older=0;
    for(size_t i=0;i<n;++i) {
        F y=ref_add(src[p[i]&MASK21],ref_mul_small(prev,scalar?(p[i]>>21)+1:fp128::conv_a(p[i])));
        if(!scalar)y=ref_add(y,ref_mul_small(older,fp128::conv_b(p[i])));
        dst[i]=y;older=prev;prev=y;
    }
}
std::array<std::vector<uint32_t>,2> conv_setup(size_t n,uint64_t seed,bool scalar) {
    // Same permutations across kernels. Independent coefficient stream keeps
    // the different coefficient alphabets from changing permutation fixtures.
    Rng perm_rng{seed^0x636f6e7632303236ULL},coeff_rng{seed^0x7461707332303236ULL};
    std::array<std::vector<uint32_t>,2> stages;
    for(auto& p:stages) {
        p=permutation(n,perm_rng);p.resize(n+1024,0);
        for(size_t i=0;i<n;++i) {
            if(scalar)p[i]|=uint32_t(coeff_rng.below(40))<<21;
            else p[i]|=(uint32_t(coeff_rng.below(3))<<21)|(uint32_t(coeff_rng.below(3))<<23);
        }
    }
    return stages;
}
template<int Id> void conv_test() {
    Rng rng{20260919};
    for(size_t n=0;n<=513;++n) {
        std::vector<F> input(n),output(n),expected(n);std::vector<uint32_t> p(n+1024,0);
        for(size_t i=0;i<n;++i) {
            input[i]=i%3==0?P-1:(i%3==1?0:rng.field());
            p[i]=uint32_t(rng.below(n));
            if constexpr(Id==0)p[i]|=uint32_t(rng.below(40))<<21;
            else p[i]|=(uint32_t(rng.below(3))<<21)|(uint32_t(rng.below(3))<<23);
        }
        conv_reference(input.data(),expected.data(),p.data(),n,Id==0);
        conv_scan<Id>(input.data(),output.data(),p.data(),n);
        if(output!=expected)throw std::runtime_error("convolution boundary/tail mismatch");
    }
}
void conv_arithmetic_test() {
    using boost::multiprecision::uint256_t;
    auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto check=[&](F x,F y,F z,unsigned a,unsigned b) {
        const __m128i zin=_mm_loadu_si128(reinterpret_cast<const __m128i*>(&z));
        if(big(fp128::conv_madd_mulx(x,a,y,b,zin))!=(big(x)*a+big(y)*b+big(z))%big(P))
            throw std::runtime_error("mulx arithmetic mismatch");
        const uint256_t combined=3*big(x)+3*big(y),delayed=3*big(z);
        fp128::CompactState compact{uint64_t(combined),uint64_t(combined>>64),
            uint64_t(delayed),uint64_t(delayed>>64),uint64_t(combined>>128)|(uint64_t(delayed>>128)<<3)};
        const __m128i compact_out=fp128::compact_step_asm(zin,compact,a,b);
        F actual;_mm_storeu_si128(reinterpret_cast<__m128i*>(&actual),compact_out);
        const uint256_t expected=(combined+big(z))%big(P);
        const uint256_t next_combined=a*expected+delayed,next_delayed=b*expected;
        if(big(actual)!=expected || compact.c0!=uint64_t(next_combined) || compact.c1!=uint64_t(next_combined>>64) ||
           compact.d0!=uint64_t(next_delayed) || compact.d1!=uint64_t(next_delayed>>64) ||
           compact.tag!=(uint64_t(next_combined>>128)|(uint64_t(next_delayed>>128)<<3)))
            throw std::runtime_error("compact state transition mismatch");
        if(big(fp128::add_asm(x,y))!=(big(x)+big(y))%big(P))
            throw std::runtime_error("asm addition mismatch");
        if(big(fp128::conv_madd_asm(x,a,y,b,z))!=(big(x)*a+big(y)*b+big(z))%big(P))
            throw std::runtime_error("asm fused arithmetic mismatch");
        F two=fp128::add_asm(x,x),three=fp128::add_asm(two,x);
        if(big(fp128::select3_asm(x,two,three,a))!=big(x)*a%big(P))
            throw std::runtime_error("asm selection mismatch");
        const auto xtwo=fp128::raw_add_asm({x,0},x),xthree=fp128::raw_add_asm(xtwo,x);
        const auto ytwo=fp128::raw_add_asm({y,0},y),ythree=fp128::raw_add_asm(ytwo,y);
        const auto sx=fp128::select_raw_asm(x,xtwo,xthree,a),sy=fp128::select_raw_asm(y,ytwo,ythree,b);
        if(big(sx.low)+(uint256_t(sx.high)<<128)!=big(x)*a ||
           big(sy.low)+(uint256_t(sy.high)<<128)!=big(y)*b ||
           big(fp128::sum_raw_asm(z,sx,sy))!=(big(x)*a+big(y)*b+big(z))%big(P))
            throw std::runtime_error("unreduced shared arithmetic mismatch");
        if(big(fp128::conv_madd(x,a,y,b,z))!=(big(x)*a+big(y)*b+big(z))%big(P))
            throw std::runtime_error("convolution arithmetic mismatch");
        F first,second;fp128::conv_prepare<false>(x,a,b,first,second);
        if(big(first)!=big(x)*a%big(P)||big(second)!=big(x)*b%big(P))
            throw std::runtime_error("shared preparation mismatch");
    };
    const F edges[]={0,1,158,159,(F(1)<<64)-1,F(1)<<64,P/2,P-2,P-1};
    for(F x:edges)for(F y:edges)for(F z:edges)for(unsigned a=1;a<=3;++a)for(unsigned b=1;b<=3;++b)check(x,y,z,a,b);
    // Composed pairs use the same helper with larger positive coefficients.
    for(F x:edges)for(F y:edges)for(F z:edges)for(unsigned a=1;a<=12;++a)for(unsigned b=1;b<=9;++b)
        if(big(fp128::conv_madd(x,a,y,b,z))!=(big(x)*a+big(y)*b+big(z))%big(P))
            throw std::runtime_error("composed arithmetic edge mismatch");
    Rng rng{20260919};
    for(unsigned i=0;i<100000;++i)check(rng.field(),rng.field(),rng.field(),rng.below(3)+1,rng.below(3)+1);
    const F raw_edges[]={0,1,P-1,P,P+1,F(-1)-1,F(-1)};
    for(F low:raw_edges)for(unsigned c=0;c<=3339;++c)
        if(big(fp128::fold_small_asm(low,c))!=(big(low)+c)%big(P))
            throw std::runtime_error("asm fold boundary mismatch");
    for(unsigned c=0;c<=3339;++c)for(int delta=-1;delta<=1;++delta) {
        const F boundaries[]={P-c+F(delta),F(0)-F(c)+F(delta)};
        for(F low:boundaries)
            if(big(fp128::fold_small_asm(low,c))!=(big(low)+c)%big(P))
                throw std::runtime_error("asm fold threshold mismatch");
    }
}
template<int Id> void conv_case(size_t k,int it,uint64_t seed) {
    const size_t n=2*k;Rng rng{seed};std::vector<F> input(k),a(n),b(n);
    for(F& x:input)x=rng.field();
    auto stages=conv_setup(n,seed,Id==0);
    std::vector<double> totals,locals,first,second;uint64_t hash=0;
    for(int run=-2;run<it;++run) {
        input[0]=add(input[0],1);auto t0=Clock::now();
        fp128::encode_block4_8<BlockKernel::contiguous>(input.data(),a.data(),k);auto t1=Clock::now();
        conv_scan<Id>(a.data(),b.data(),stages[0].data(),n);auto t2=Clock::now();
        conv_scan<Id>(b.data(),a.data(),stages[1].data(),n);auto t3=Clock::now();
        if(run>=0){locals.push_back(ms(t0,t1));first.push_back(ms(t1,t2));second.push_back(ms(t2,t3));totals.push_back(ms(t0,t3));}
        hash=checksum(a);
    }
    std::vector<F> expected(n),temp(n);dense_local(input.data(),expected.data(),k);
    for(const auto& p:stages){conv_reference(expected.data(),temp.data(),p.data(),n,Id==0);expected.swap(temp);}
    if(a!=expected)throw std::runtime_error("complete convolution encoder mismatch");
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"kernel\":\""<<conv_names[Id]<<"\",\"k\":"<<k<<",\"n\":"<<n
      <<",\"iterations\":"<<it<<",\"seed\":"<<seed<<",\"validated\":true,\"checksum\":"<<hash;
    print_stat("local_ms",locals);print_stat("stage0_ms",first);print_stat("stage1_ms",second);print_stat("total_ms",totals);
    std::cout<<"}\n"<<std::flush;
}
template<int Id=0> void conv_dispatch(int id,size_t k,int it,uint64_t seed,bool test) {
    if(id==Id){if(test)conv_test<Id>();conv_case<Id>(k,it,seed);}
    else if constexpr(Id+1<CONV_CASES)conv_dispatch<Id+1>(id,k,it,seed,test);
    else throw std::runtime_error("invalid case");
}
int main(int argc,char** argv) {
    try {
        int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        int spin_lock=open("/tmp/bare-spin-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(spin_lock<0||flock(spin_lock,LOCK_EX|LOCK_NB))throw std::runtime_error("SPIN benchmark lock unavailable");
        size_t k=1<<20;int it=9,selected=-1;uint64_t seed=20260919;bool test=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto value=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--k")k=std::stoull(value());else if(arg=="--iterations")it=std::stoi(value());
            else if(arg=="--seed")seed=std::stoull(value());else if(arg=="--case")selected=std::stoi(value());
            else if(arg=="--test")test=true;else throw std::runtime_error("unknown option");
        }
        if(test){conv_arithmetic_test();k=256;it=1;}
        if(k<4||k%4||k>(1u<<20)||it<1||selected < -1||selected>=CONV_CASES)throw std::runtime_error("invalid options");
        if(selected>=0)conv_dispatch(selected,k,it,seed,test);
        else for(int id=0;id<CONV_CASES;++id)conv_dispatch(id,k,it,seed,test);
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
