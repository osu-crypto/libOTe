// Single-threaded addition-only encoder benchmark. Setup is outside timed encoding.
// Build: g++ -O3 -march=native -DNDEBUG -std=c++20 encoder_bench.cpp -o encoder_bench
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>
#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>
#include <boost/multiprecision/cpp_int.hpp>

using F = unsigned __int128;
constexpr F P = F(-1) - 158; // 2^128 - 159; all stored elements canonical.
using Clock = std::chrono::steady_clock;
volatile uint64_t sink = 0;

inline F add(F a, F b) {
    F s = a + b;
    s += F(159) & (F(0) - F(s < a));
    return s - (P & (F(0) - F(s >= P)));
}
F ref_add(F a, F b) { return a >= P-b ? a-(P-b) : a+b; }
F ref_mul_small(F a, unsigned c) {
    F s = 0;
    while (c--) s = ref_add(s,a);
    return s;
}

struct Rng {
    uint64_t s;
    uint64_t next() {
        uint64_t z = (s += 0x9e3779b97f4a7c15ULL);
        z = (z^(z>>30))*0xbf58476d1ce4e5b9ULL;
        z = (z^(z>>27))*0x94d049bb133111ebULL;
        return z^(z>>31);
    }
    uint64_t below(uint64_t bound) {
        const uint64_t threshold = -bound % bound;
        for (;;) { uint64_t x=next(); if (x>=threshold) return x%bound; }
    }
    F field() {
        for (;;) { F x=(F(next())<<64)|next(); if (x<P) return x; }
    }
};

enum class Block { subset, repeat5, pair6, poly16, product16 };
const char* block_name(Block b) {
    switch(b) {
    case Block::subset:return "subset4_15";
    case Block::repeat5:return "repeat5";
    case Block::pair6:return "pair2_6";
    case Block::poly16:return "poly16_48";
    default:return "product16_64";
    }
}
size_t length(Block b,size_t k) {
    switch(b) {
    case Block::subset:return k/4*15;
    case Block::repeat5:return k*5;
    case Block::pair6:case Block::poly16:return k*3;
    default:return k*4;
    }
}
size_t block_additions(Block b,size_t k) {
    switch(b) {
    case Block::subset:return k/4*11;
    case Block::repeat5:return 0;
    case Block::pair6:return k*2;
    case Block::poly16:return k/16*585;
    default:return k/16*180;
    }
}

template<int B,int M> inline void polynomial(const F* __restrict in,F* __restrict out) {
    F state[B];
    #pragma GCC unroll 16
    for(int j=0;j<B;++j) state[j]=in[j];
    out[0]=state[0]; out[M-1]=state[B-1];
    for(int step=0;step<M-2;++step) {
        #pragma GCC unroll 16
        for(int j=0;j<B-1;++j)
            if(j<M-2-step) state[j]=add(state[j],state[j+1]);
        out[step+1]=state[0];
    }
}
void encode_b(Block b,const F* __restrict in,F* __restrict out,size_t k) {
    switch(b) {
    case Block::subset:
        for(size_t i=0,j=0;i<k;i+=4,j+=15) {
            F a=in[i],b=in[i+1],c=in[i+2],d=in[i+3];
            out[j]=a; out[j+1]=b; out[j+2]=add(a,b); out[j+3]=c;
            out[j+4]=add(a,c); out[j+5]=add(b,c); out[j+6]=add(out[j+2],c);
            out[j+7]=d; out[j+8]=add(a,d); out[j+9]=add(b,d);
            out[j+10]=add(out[j+2],d); out[j+11]=add(c,d);
            out[j+12]=add(out[j+4],d); out[j+13]=add(out[j+5],d);
            out[j+14]=add(out[j+6],d);
        }
        break;
    case Block::repeat5:
        for(size_t i=0;i<k;++i) {
            F v=in[i]; out[5*i]=v;out[5*i+1]=v;out[5*i+2]=v;out[5*i+3]=v;out[5*i+4]=v;
        }
        break;
    case Block::pair6:
        for(size_t i=0,j=0;i<k;i+=2,j+=6) {
            F a=in[i],b=in[i+1];out[j]=a;
            out[j+1]=a=add(a,b);out[j+2]=a=add(a,b);
            out[j+3]=a=add(a,b);out[j+4]=add(a,b);out[j+5]=b;
        }
        break;
    case Block::poly16:
        for(size_t i=0,j=0;i<k;i+=16,j+=48) polynomial<16,48>(in+i,out+j);
        break;
    case Block::product16:
        for(size_t i=0,j=0;i<k;i+=16,j+=64) {
            alignas(64) F rows[32],column[4],encoded[8];
            polynomial<4,8>(in+i,rows);polynomial<4,8>(in+i+4,rows+8);
            polynomial<4,8>(in+i+8,rows+16);polynomial<4,8>(in+i+12,rows+24);
            for(int c=0;c<8;++c) {
                column[0]=rows[c];column[1]=rows[8+c];column[2]=rows[16+c];column[3]=rows[24+c];
                polynomial<4,8>(column,encoded);
                #pragma GCC unroll 8
                for(int r=0;r<8;++r) out[j+8*r+c]=encoded[r];
            }
        }
    }
}

std::vector<uint32_t> permutation(size_t n,Rng& rng) {
    std::vector<uint32_t> p(n+64,0);std::iota(p.begin(),p.begin()+n,0u);
    for(size_t i=n-1;i>0;--i) std::swap(p[i],p[rng.below(i+1)]);
    return p;
}
template<int PF> void permute_accumulate(const F* __restrict in,F* __restrict out,
                                        const uint32_t* __restrict p,size_t n) {
    F total=in[p[0]];out[0]=total;
    for(size_t i=1;i<n;++i) {
        if constexpr(PF) __builtin_prefetch(in+p[i+PF],0,1);
        total=add(total,in[p[i]]);out[i]=total;
    }
}
template<int PF> void permute_only(const F* __restrict in,F* __restrict out,
                                  const uint32_t* __restrict p,size_t n) {
    for(size_t i=0;i<n;++i) {
        if constexpr(PF) __builtin_prefetch(in+p[i+PF],0,1);
        out[i]=in[p[i]];
    }
}
void accumulate(F* p,size_t n) { F t=p[0];for(size_t i=1;i<n;++i) p[i]=t=add(t,p[i]); }

// Coefficient buckets are generated once at setup. Nonzero terms are stored in
// descending coefficient order. No multiplication or allocation in encoding.
template<int C,class Index,int PF> inline void weighted_steps(const F* src,
        const Index*& indices,const uint8_t* counts,F& running,F& total,bool& live) {
    const unsigned count=counts[C-1];
    if(count) {
        if constexpr(PF) __builtin_prefetch(src+indices[PF],0,1);
        F bucket=src[*indices++];
        for(unsigned j=1;j<count;++j) {
            if constexpr(PF) __builtin_prefetch(src+indices[PF],0,1);
            bucket=add(bucket,src[*indices++]);
        }
        if(live) running=add(running,bucket);else running=bucket;
    }
    if(live) total=add(total,running);
    else if(count) {total=running;live=true;}
    if constexpr(C>1) weighted_steps<C-1,Index,PF>(src,indices,counts,running,total,live);
}
template<int Q,class Index,int PF=0> inline F weighted_sum(const F* src,const Index*& indices,
                                                          const uint8_t* counts) {
    F running=0,total=0;bool live=false;
    weighted_steps<Q-1,Index,PF>(src,indices,counts,running,total,live);return total;
}
size_t weight_adds(const uint8_t* counts,int q) {
    size_t terms=0;int high=0;
    for(int c=1;c<q;++c) {terms+=counts[c-1];if(counts[c-1]) high=c;}
    return terms ? terms+high-2 : 0;
}

template<int D,int Q> struct Independent {
    std::vector<uint32_t> indices;
    std::vector<uint8_t> counts;
    size_t additions=0,terms=0;
    Independent(size_t k,size_t n,Rng& rng):counts(k*(Q-1)) {
        indices.reserve(k*D+64);
        for(size_t row=0;row<k;++row) {
            uint32_t ids[D];uint8_t coeff[D];auto* cs=counts.data()+row*(Q-1);
            for(int j=0;j<D;++j) {ids[j]=rng.below(n);coeff[j]=rng.below(Q);if(coeff[j]) ++cs[coeff[j]-1];}
            for(int c=Q-1;c>=1;--c) for(int j=0;j<D;++j) if(coeff[j]==c) indices.push_back(ids[j]);
            additions+=weight_adds(cs,Q);
        }
        terms=indices.size();indices.resize(terms+64,0);indices.shrink_to_fit();
    }
    template<int PF> void apply(const F* src,F* dst,size_t k) const {
        const uint32_t* ids=indices.data();
        for(size_t row=0;row<k;++row) dst[row]=weighted_sum<Q,uint32_t,PF>(src,ids,counts.data()+row*(Q-1));
    }
    size_t bytes() const {return indices.capacity()*4+counts.capacity();}
    size_t reads() const {return terms;}
    void validate(const F* src,const F* dst,size_t k) const {
        size_t pos=0;
        for(size_t row=0;row<k;++row) {
            F ref=0;for(int c=Q-1;c>=1;--c) for(int j=0;j<counts[row*(Q-1)+c-1];++j)
                ref=ref_add(ref,ref_mul_small(src[indices[pos++]],c));
            if(ref!=dst[row]) throw std::runtime_error("independent mixer mismatch");
        }
        if(pos!=terms) throw std::runtime_error("bad independent schedule");
    }
};

template<int D,int Q,int R> struct Shared {
    struct Group {std::array<uint32_t,D> ids;uint8_t offsets[R][D];uint8_t counts[R][Q-1];};
    std::vector<Group> groups;size_t additions=0,terms=0;
    Shared(size_t k,size_t n,Rng& rng):groups(k/R) {
        for(auto& g:groups) {
            for(auto& id:g.ids) id=rng.below(n);
            for(int r=0;r<R;++r) {
                uint8_t coeff[D];
                for(int j=0;j<D;++j) {coeff[j]=rng.below(Q);if(coeff[j]) ++g.counts[r][coeff[j]-1];}
                int pos=0;for(int c=Q-1;c>=1;--c) for(int j=0;j<D;++j)
                    if(coeff[j]==c) g.offsets[r][pos++]=j;
                terms+=pos;additions+=weight_adds(g.counts[r],Q);
            }
        }
    }
    template<int PF> void apply(const F* src,F* dst,size_t) const {
        for(size_t i=0;i<groups.size();++i) {
            const auto& g=groups[i];
            if constexpr(PF) {
                if(i+2<groups.size()) for(auto id:groups[i+2].ids) __builtin_prefetch(src+id,0,1);
            }
            alignas(64) F values[D];
            #pragma GCC unroll 8
            for(int j=0;j<D;++j) values[j]=src[g.ids[j]];
            #pragma GCC unroll 4
            for(int r=0;r<R;++r) {
                const uint8_t* ids=g.offsets[r];dst[i*R+r]=weighted_sum<Q,uint8_t>(values,ids,g.counts[r]);
            }
        }
    }
    size_t bytes() const {return groups.capacity()*sizeof(Group);}
    size_t reads() const {return groups.size()*D;}
    void validate(const F* src,const F* dst,size_t) const {
        for(size_t i=0;i<groups.size();++i) for(int r=0;r<R;++r) {
            const auto& g=groups[i];F ref=0;int pos=0;
            for(int c=Q-1;c>=1;--c) for(int j=0;j<g.counts[r][c-1];++j)
                ref=ref_add(ref,ref_mul_small(src[g.ids[g.offsets[r][pos++]]],c));
            if(ref!=dst[i*R+r]) throw std::runtime_error("shared mixer mismatch");
        }
    }
};
// Same shared-row linear map, but store packed coefficients and always add to
// fixed local buckets (including bucket zero). More additions, fewer branches
// and fewer schedule bytes than the exact-addition-count implementation.
template<int D,int R> struct SharedDirect {
    struct Group {std::array<uint32_t,D> ids;uint8_t coefficients[D][R/2];};
    std::vector<Group> groups;size_t additions=0,terms=0;
    SharedDirect(size_t k,size_t n,Rng& rng):groups(k/R),additions(k*(D+28)) {
        static_assert(R==2||R==4);
        for(auto& g:groups) {
            for(auto& id:g.ids) id=rng.below(n);
            for(int r=0;r<R;++r) for(int j=0;j<D;++j) {
                unsigned c=rng.below(16);terms+=(c!=0);
                g.coefficients[j][r/2]|=c<<(4*(r%2));
            }
        }
    }
    template<int PF> void apply(const F* src,F* dst,size_t) const {
        for(size_t i=0;i<groups.size();++i) {
            const auto& g=groups[i];
            if constexpr(PF) if(i+2<groups.size())
                for(auto id:groups[i+2].ids) __builtin_prefetch(src+id,0,1);
            alignas(64) F buckets[R][16]={};
            for(int j=0;j<D;++j) {
                F v=src[g.ids[j]];
                #pragma GCC unroll 4
                for(int r=0;r<R;++r) {
                    unsigned c=(g.coefficients[j][r/2]>>(4*(r%2)))&15;
                    buckets[r][c]=add(buckets[r][c],v);
                }
            }
            #pragma GCC unroll 4
            for(int r=0;r<R;++r) {
                F running=buckets[r][15],total=running;
                #pragma GCC unroll 16
                for(int c=14;c>=1;--c) {running=add(running,buckets[r][c]);total=add(total,running);}
                dst[i*R+r]=total;
            }
        }
    }
    size_t bytes() const {return groups.capacity()*sizeof(Group);}
    size_t reads() const {return groups.size()*D;}
    void validate(const F* src,const F* dst,size_t) const {
        for(size_t i=0;i<groups.size();++i) for(int r=0;r<R;++r) {
            F ref=0;const auto& g=groups[i];
            for(int j=0;j<D;++j) ref=ref_add(ref,ref_mul_small(src[g.ids[j]],(g.coefficients[j][r/2]>>(4*(r%2)))&15));
            if(ref!=dst[i*R+r]) throw std::runtime_error("direct shared mixer mismatch");
        }
    }
};
struct Local {
    std::vector<uint32_t> ids;size_t additions,terms;
    Local(size_t k,size_t n,Rng& rng):ids(permutation(n,rng)),additions(n-k),terms(n) {
        if(n!=3*k) throw std::runtime_error("local mixer requires pair6");
    }
    template<int PF> void apply(const F* src,F* dst,size_t k) const {
        for(size_t i=0;i<k;++i) {
            if constexpr(PF) {__builtin_prefetch(src+ids[3*i+PF],0,1);}
            dst[i]=add(add(src[ids[3*i]],src[ids[3*i+1]]),src[ids[3*i+2]]);
        }
    }
    size_t bytes() const {return ids.capacity()*4;}
    size_t reads() const {return terms;}
    void validate(const F* src,const F* dst,size_t k) const {
        for(size_t i=0;i<k;++i) if(dst[i]!=ref_add(ref_add(src[ids[3*i]],src[ids[3*i+1]]),src[ids[3*i+2]]))
            throw std::runtime_error("local mixer mismatch");
    }
};

double ms(Clock::time_point a,Clock::time_point b) {return std::chrono::duration<double,std::milli>(b-a).count();}
uint64_t checksum(const std::vector<F>& v) {
    uint64_t h=0x123456789abcdef0ULL;
    for(F x:v) h=std::rotl(h,7)^uint64_t(x)^uint64_t(x>>64);
    sink=h;return h;
}
struct Stats {double low,median,high;};
Stats stats(std::vector<double> v) {std::sort(v.begin(),v.end());return {v.front(),v[v.size()/2],v.back()};}
void print_stat(const char* name,const std::vector<double>& v) {
    auto s=stats(v);std::cout<<",\""<<name<<"\":{\"min\":"<<s.low<<",\"median\":"<<s.median<<",\"max\":"<<s.high<<",\"samples\":[";
    for(size_t i=0;i<v.size();++i) {if(i) std::cout<<',';std::cout<<v[i];}
    std::cout<<"]}";
}

template<class Mixer,int PF> void bench(const std::string& name,Block block,size_t k,int iterations,
                                       bool split,bool validate,uint64_t seed) {
    const size_t n=length(block,k);Rng rng{seed};
    auto start=Clock::now();
    std::vector<F> input(k),a(n),b(n),output(2*k);
    for(auto& x:input) x=rng.field();
    auto p1=permutation(n,rng),p2=permutation(n,rng);
    Mixer mixer(k,n,rng);double setup=ms(start,Clock::now());
    std::vector<double> totals,bs,pa1,pa2,mixes,copies;
    uint64_t digest=0;
    for(int run=-2;run<iterations;++run) {
        // Change the input so repeated encodes are observable; pages stay resident.
        input[0]=add(input[0],1);
        auto t0=Clock::now();
        encode_b(block,input.data(),a.data(),k);auto t1=Clock::now();
        if(split) {permute_only<PF>(a.data(),b.data(),p1.data(),n);accumulate(b.data(),n);}
        else permute_accumulate<PF>(a.data(),b.data(),p1.data(),n);
        auto t2=Clock::now();
        if(split) {permute_only<PF>(b.data(),a.data(),p2.data(),n);accumulate(a.data(),n);}
        else permute_accumulate<PF>(b.data(),a.data(),p2.data(),n);
        auto t3=Clock::now();mixer.template apply<PF>(a.data(),output.data()+k,k);auto t4=Clock::now();
        std::memcpy(output.data(),input.data(),k*sizeof(F));auto t5=Clock::now();
        digest=checksum(output); // Full output consumed outside timing, not a sampled checksum.
        if(run>=0) {totals.push_back(ms(t0,t5));bs.push_back(ms(t0,t1));pa1.push_back(ms(t1,t2));
            pa2.push_back(ms(t2,t3));mixes.push_back(ms(t3,t4));copies.push_back(ms(t4,t5));}
    }
    if(validate) {
        std::vector<F> x(n),y(n);encode_b(block,input.data(),x.data(),k);
        F t=0;for(size_t i=0;i<n;++i) y[i]=t=ref_add(t,x[p1[i]]);
        t=0;for(size_t i=0;i<n;++i) x[i]=t=ref_add(t,y[p2[i]]);
        if(x!=a||y!=b) throw std::runtime_error("precode mismatch");
        if(!std::equal(input.begin(),input.end(),output.begin())) throw std::runtime_error("systematic mismatch");
        mixer.validate(a.data(),output.data()+k,k);
    }
    const size_t additions=block_additions(block,k)+2*(n-1)+mixer.additions;
    const size_t fields=(input.capacity()+a.capacity()+b.capacity()+output.capacity())*sizeof(F);
    const size_t permutations=(p1.capacity()+p2.capacity())*sizeof(uint32_t);
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"case\":\""<<name<<"\",\"block\":\""<<block_name(block)
      <<"\",\"k\":"<<k<<",\"n\":"<<2*k<<",\"intermediate\":"<<n<<",\"iterations\":"<<iterations
      <<",\"seed\":"<<seed<<",\"prefetch\":"<<PF<<",\"split_permute_accumulate\":"<<(split?"true":"false")
      <<",\"validated\":"<<(validate?"true":"false")<<",\"setup_ms\":"<<setup
      <<",\"additions\":"<<additions<<",\"mixer_additions\":"<<mixer.additions
      <<",\"mixer_reads\":"<<mixer.reads()<<",\"nonzero_terms\":"<<mixer.terms
      <<",\"field_bytes\":"<<fields<<",\"permutation_bytes\":"<<permutations<<",\"mixer_schedule_bytes\":"<<mixer.bytes()
      <<",\"resident_payload_bytes\":"<<fields+permutations+mixer.bytes()<<",\"checksum\":"<<digest;
    print_stat("total_ms",totals);print_stat("b_ms",bs);print_stat("pa1_ms",pa1);print_stat("pa2_ms",pa2);
    print_stat("mixer_ms",mixes);print_stat("copy_ms",copies);std::cout<<"}\n"<<std::flush;
}

void field_tests() {
    using boost::multiprecision::cpp_int;
    const F edges[]={0,1,158,159,F(1)<<64,(F(1)<<127)-1,F(1)<<127,P-2,P-1};
    auto check=[](F a,F b) {
        cpp_int biga=(cpp_int(uint64_t(a>>64))<<64)+uint64_t(a);
        cpp_int bigb=(cpp_int(uint64_t(b>>64))<<64)+uint64_t(b);
        cpp_int mod=(cpp_int(1)<<128)-159,expected=(biga+bigb)%mod;
        F answer=(F((expected>>64).convert_to<uint64_t>())<<64)|expected.convert_to<uint64_t>();
        if(add(a,b)!=answer||ref_add(a,b)!=answer) throw std::runtime_error("field addition mismatch");
    };
    for(F a:edges) for(F b:edges) check(a,b);
    Rng rng{123};for(int i=0;i<100000;++i) check(rng.field(),rng.field());
    // Independently derive the polynomial evaluation matrix over the field.
    for(auto [dim,len]:{std::pair{2,6},std::pair{4,8},std::pair{16,48}}) {
        for(int basis=0;basis<dim;++basis) {
            F input[16]={},out[64]={};input[basis]=1;
            if(dim==2) polynomial<2,6>(input,out);
            else if(dim==4) polynomial<4,8>(input,out);else polynomial<16,48>(input,out);
            for(int t=0;t<len-1;++t) {
                F value=0;
                if(t>=basis) {value=1;for(int j=1;j<=basis;++j) value=value*(t-j+1)/j;}
                if(out[t]!=value) throw std::runtime_error("polynomial basis mismatch");
            }
            if(out[len-1]!=F(basis==dim-1)) throw std::runtime_error("infinity mismatch");
        }
    }
    for(int basis=0;basis<16;++basis) {
        F in[16]={},out[64],a[8],b[8],ia[4]={},ib[4]={};in[basis]=1;ia[basis/4]=1;ib[basis%4]=1;
        encode_b(Block::product16,in,out,16);polynomial<4,8>(ia,a);polynomial<4,8>(ib,b);
        for(int i=0;i<8;++i) for(int j=0;j<8;++j) if(out[8*i+j]!=a[i]*b[j]) throw std::runtime_error("tensor mismatch");
    }
    for(int basis=0;basis<4;++basis) {
        F in[4]={},out[15];in[basis]=1;encode_b(Block::subset,in,out,4);
        for(int m=1;m<16;++m) if(out[m-1]!=F((m>>basis)&1)) throw std::runtime_error("subset mismatch");
    }
    std::cerr<<"Field and local circuit tests passed.\n";
}
template<int PF> void dispatch(const std::string& c,size_t k,int it,bool split,bool check,uint64_t seed) {
    if(c=="subset_independent") bench<Independent<25,6>,PF>(c,Block::subset,k,it,split,check,seed);
    else if(c=="subset_shared2") bench<Shared<32,16,2>,PF>(c,Block::subset,k,it,split,check,seed);
    else if(c=="subset_shared4") bench<Shared<60,16,4>,PF>(c,Block::subset,k,it,split,check,seed);
    else if(c=="subset_shared2_direct") bench<SharedDirect<32,2>,PF>(c,Block::subset,k,it,split,check,seed);
    else if(c=="subset_shared4_direct") bench<SharedDirect<60,4>,PF>(c,Block::subset,k,it,split,check,seed);
    else if(c=="repeat5_independent") bench<Independent<21,7>,PF>(c,Block::repeat5,k,it,split,check,seed);
    else if(c=="pair6_independent") bench<Independent<29,8>,PF>(c,Block::pair6,k,it,split,check,seed);
    else if(c=="poly16_independent") bench<Independent<31,7>,PF>(c,Block::poly16,k,it,split,check,seed);
    else if(c=="product16_exploratory") bench<Independent<25,6>,PF>(c,Block::product16,k,it,split,check,seed);
    else if(c=="pair6_local_open") bench<Local,PF>(c,Block::pair6,k,it,split,check,seed);
    else throw std::runtime_error("unknown case");
}
int main(int argc,char** argv) {
    try {
        // All instances of this harness share the lock: never overlap benchmarks.
        const int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB)) throw std::runtime_error("another benchmark is running, or lock unavailable");
        std::string name="all";size_t k=1u<<20;int it=9,pf=32;bool split=false,check=false,test=false,reverse=false;uint64_t seed=20260918;
        for(int i=1;i<argc;++i) {
            std::string a=argv[i];
            auto value=[&](){if(++i==argc) throw std::runtime_error("missing argument");return std::string(argv[i]);};
            if(a=="--case") name=value();else if(a=="--k") k=std::stoull(value());
            else if(a=="--iterations") it=std::stoi(value());else if(a=="--prefetch") pf=std::stoi(value());
            else if(a=="--seed") seed=std::stoull(value());else if(a=="--split") split=true;
            else if(a=="--check") check=true;else if(a=="--test") test=true;
            else if(a=="--reverse") reverse=true;
            else throw std::runtime_error("unknown argument: "+a);
        }
        if(k<16||k%16||k>size_t(UINT32_MAX)/5||it<1||(pf!=0&&pf!=32)) throw std::runtime_error("invalid dimensions/options");
        if(test) {field_tests();check=true;k=256;it=1;name="all";}
        std::vector<std::string> cases={"subset_independent","subset_shared2","subset_shared4","subset_shared2_direct","subset_shared4_direct","repeat5_independent",
            "pair6_independent","poly16_independent","product16_exploratory","pair6_local_open"};
        if(reverse) std::reverse(cases.begin(),cases.end());
        auto run=[&](const std::string& c) {if(pf) dispatch<32>(c,k,it,split,check,seed);else dispatch<0>(c,k,it,split,check,seed);};
        if(name=="all") for(const auto& c:cases) run(c);else run(name);
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
