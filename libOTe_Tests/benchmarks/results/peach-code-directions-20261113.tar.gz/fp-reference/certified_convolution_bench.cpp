#define SCAN_SCHEDULE_NO_MAIN
#include "scan_schedule_bench.cpp"
#include "fp128_block8_16.h"
#include "fp128_certified_convolution.h"

template<int Id> struct CertifiedConfig {
    static constexpr unsigned width=Id==0?1:Id==1?2:4;
    static constexpr unsigned q=Id==0?256:Id==1?2048:65536;
    using Word=std::conditional_t<Id==0,uint32_t,std::conditional_t<Id==1,uint64_t,fp128::CertifiedFour::Word>>;
    static const char* name(){if constexpr(Id==0)return "w1_q256_control";if constexpr(Id==1)return "w2_q2048_mulx";if constexpr(Id==2)return "w4_q65536_one_fold";return "w4_q65536_two_folds";}
    static Word pack(uint32_t i,const std::array<unsigned,width>& c) {
        if constexpr(Id==0)return i|((c[0]-1)<<21);
        else if constexpr(Id==1)return fp128::CertifiedTwo::pack(i,c[0],c[1]);
        else return fp128::CertifiedFour::pack(i,c[0],c[1],c[2],c[3]);
    }
    static uint32_t index(Word p){if constexpr(Id<2)return uint32_t(p&MASK21);else return fp128::CertifiedFour::index(p);}
    static unsigned coefficient(Word p,unsigned j) {
        if constexpr(Id==0)return (p>>21)+1;
        else if constexpr(Id==1)return j?fp128::CertifiedTwo::b(p):fp128::CertifiedTwo::a(p);
        else {const unsigned v[]={fp128::CertifiedFour::a(p),fp128::CertifiedFour::b(p),fp128::CertifiedFour::c(p),fp128::CertifiedFour::d(p)};return v[j];}
    }
    static void scan(const F* src,F* dst,const Word* p,size_t n) {
        if constexpr(Id==0)fp128::scan_scheduled<256,16>(src,dst,p,n);
        else if constexpr(Id==1)fp128::convolution_alphabet<fp128::CertifiedTwo>(src,dst,p,n);
        else fp128::certified_scan4<Id==3>(src,dst,p,n);
    }
};

unsigned choose(unsigned n,unsigned j){if(j>n)return 0;unsigned v=1;for(unsigned a=1;a<=j;++a)v=v*(n+1-a)/a;return v;}
void certified_local_reference(const F* x,F* y,size_t k) {
    for(size_t i=0;i<k;i+=8) {
        for(unsigned t=0;t<15;++t) {
            F s=0;for(unsigned j=0;j<8;++j)s=ref_add(s,fp128::mul(x[i+j],choose(t,j)));
            y[2*i+t]=s;
        }
        y[2*i+15]=x[i+7];
    }
}
template<int Id> auto certified_setup(size_t n,uint64_t seed) {
    using C=CertifiedConfig<Id>;Rng prng{seed^0x636572742d706572ULL},crng{seed^0x636572742d636f65ULL};
    std::array<std::vector<typename C::Word>,2> stages;
    for(auto& p:stages) {
        auto indices=permutation(n,prng);p.resize(n+1024);
        for(size_t i=0;i<n;++i) {
            std::array<unsigned,C::width> c;
            for(auto& a:c)a=unsigned(crng.below(C::q)+1);
            p[i]=C::pack(indices[i],c);
        }
    }
    return stages;
}
template<int Id> void certified_reference(const F* src,F* dst,const typename CertifiedConfig<Id>::Word* p,size_t n) {
    using C=CertifiedConfig<Id>;
    for(size_t i=0;i<n;++i) {
        F s=src[C::index(p[i])];
        for(unsigned j=0;j<C::width && j<i;++j)s=ref_add(s,fp128::mul(dst[i-j-1],C::coefficient(p[i],j)));
        dst[i]=s;
    }
}
void certified_arithmetic_test() {
    using boost::multiprecision::uint256_t;
    auto big=[](F x){return (uint256_t(uint64_t(x>>64))<<64)|uint64_t(x);};
    auto check=[&](F a,F b,F c,F d,F in,unsigned ca,unsigned cb,unsigned cc,unsigned cd) {
        const auto input=_mm_loadu_si128(reinterpret_cast<const __m128i*>(&in));
        const auto expected=(big(a)*ca+big(b)*cb+big(c)*cc+big(d)*cd+big(in))%big(P);
        if(big(fp128::certified_madd4<false>(a,b,c,d,ca,cb,cc,cd,input))!=expected ||
           big(fp128::certified_madd4<true>(a,b,c,d,ca,cb,cc,cd,input))!=expected)
            throw std::runtime_error("four-tap integer oracle mismatch");
        const unsigned x=ca%2048+1,y=cb%2048+1;
        if(big(fp128::conv_madd_mulx(a,x,b,y,input))!=(big(a)*x+big(b)*y+big(in))%big(P))
            throw std::runtime_error("two-tap integer oracle mismatch");
    };
    const F edges[]={0,1,(F(1)<<64)-1,F(1)<<64,P-159,P-1};
    for(F a:edges)for(F b:edges)for(F c:edges)for(F d:edges)for(F in:edges) {
        check(a,b,c,d,in,1,1,1,1);check(a,b,c,d,in,65536,65536,65536,65536);
        check(a,b,c,d,in,1,65536,2,65535);
    }
    Rng rng{20260923};
    for(unsigned i=0;i<100000;++i)check(rng.field(),rng.field(),rng.field(),rng.field(),rng.field(),
        unsigned(rng.below(65536)+1),unsigned(rng.below(65536)+1),unsigned(rng.below(65536)+1),unsigned(rng.below(65536)+1));
    for(size_t k=8;k<=520;k+=8) {
        std::vector<F> input(k),out(2*k),ref(2*k);
        for(unsigned pattern=0;pattern<4;++pattern) {
            for(size_t i=0;i<k;++i)input[i]=pattern==0?P-1:pattern==1?(i%8==7?1:0):pattern==2?edges[i%6]:rng.field();
            fp128::encode_block8_16(input.data(),out.data(),k);
            certified_local_reference(input.data(),ref.data(),k);
            if(out!=ref)throw std::runtime_error("Newton 8->16 reference mismatch");
            for(size_t block=0;block<k;block+=8)for(unsigned t=0;t<15;++t) {
                uint256_t sum=0;for(unsigned j=0;j<8;++j)sum+=big(input[block+j])*choose(t,j);
                if(big(out[2*block+t])!=sum%big(P))throw std::runtime_error("Newton integer oracle mismatch");
            }
        }
    }
}
template<int Id> void certified_test() {
    using C=CertifiedConfig<Id>;Rng rng{20260923};
    for(size_t n=0;n<=513;++n) {
        std::vector<F> input(n),out(n),ref(n);std::vector<typename C::Word> meta(n+1024);
        for(size_t i=0;i<n;++i) {
            input[i]=i%3==0?P-1:i%3==1?0:rng.field();std::array<unsigned,C::width> c;
            for(unsigned j=0;j<C::width;++j)c[j]=i%3==0?C::q:i%3==1?1:unsigned(rng.below(C::q)+1);
            unsigned index=unsigned(rng.below(n));meta[i]=C::pack(index,c);
            if(C::index(meta[i])!=index)throw std::runtime_error("index roundtrip");
            for(unsigned j=0;j<C::width;++j)if(C::coefficient(meta[i],j)!=c[j])throw std::runtime_error("coefficient roundtrip");
        }
        C::scan(input.data(),out.data(),meta.data(),n);certified_reference<Id>(input.data(),ref.data(),meta.data(),n);
        if(out!=ref)throw std::runtime_error("scan/tail reference mismatch");
    }
    std::array<unsigned,C::width> c;c.fill(C::q);const auto m=C::pack(MASK21,c);
    if(C::index(m)!=MASK21)throw std::runtime_error("maximum index mismatch");
    for(unsigned j=0;j<C::width;++j)if(C::coefficient(m,j)!=C::q)throw std::runtime_error("maximum coefficient mismatch");
}
template<int Id> void certified_case(size_t k,int it,uint64_t seed) {
    using C=CertifiedConfig<Id>;const size_t n=2*k;Rng rng{seed};std::vector<F> input(k),a(n),b(n);
    for(F& x:input)x=rng.field();const auto setup0=Clock::now();auto stages=certified_setup<Id>(n,seed);const auto setup1=Clock::now();
    std::vector<double> totals,locals,first,second;uint64_t hash=0;
    for(int run=-2;run<it;++run) {
        input[0]=add(input[0],1);auto t0=Clock::now();
        fp128::encode_block8_16(input.data(),a.data(),k);auto t1=Clock::now();
        C::scan(a.data(),b.data(),stages[0].data(),n);auto t2=Clock::now();
        C::scan(b.data(),a.data(),stages[1].data(),n);auto t3=Clock::now();
        if(run>=0){locals.push_back(ms(t0,t1));first.push_back(ms(t1,t2));second.push_back(ms(t2,t3));totals.push_back(ms(t0,t3));}
        hash=checksum(a);
    }
    std::vector<F> expected(n),temp(n);certified_local_reference(input.data(),expected.data(),k);
    for(const auto& p:stages){certified_reference<Id>(expected.data(),temp.data(),p.data(),n);expected.swap(temp);}
    if(a!=expected)throw std::runtime_error("complete certified encoder mismatch");
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"kernel\":\""<<C::name()<<"\",\"width\":"<<C::width<<",\"q\":"<<C::q
      <<",\"precode\":\"extended_newton_8_16\",\"metadata_bytes\":"<<sizeof(typename C::Word)<<",\"k\":"<<k<<",\"n\":"<<n
      <<",\"metadata_total_bytes\":"<<2*(n+1024)*sizeof(typename C::Word)<<",\"payload_bytes\":"<<16*(k+2*n)+2*(n+1024)*sizeof(typename C::Word)
      <<",\"setup_ms\":"<<ms(setup0,setup1)<<",\"iterations\":"<<it<<",\"seed\":"<<seed<<",\"validated\":true,\"checksum\":"<<hash;
    print_stat("local_ms",locals);print_stat("stage0_ms",first);print_stat("stage1_ms",second);print_stat("total_ms",totals);
    std::cout<<",\"samples_ms\":[";for(size_t i=0;i<totals.size();++i){if(i)std::cout<<',';std::cout<<totals[i];}std::cout<<"]}\n"<<std::flush;
}
template<int Id=0> void certified_dispatch(int id,size_t k,int it,uint64_t seed,bool test) {
    if(id==Id){if(test)certified_test<Id>();certified_case<Id>(k,it,seed);}
    else if constexpr(Id<3)certified_dispatch<Id+1>(id,k,it,seed,test);
    else throw std::runtime_error("invalid case");
}
int main(int argc,char** argv) {
    try {
        for(const char* path:{"/tmp/prindal-addition-encoder-benchmark.lock","/tmp/bare-spin-benchmark.lock","/tmp/hypercat-benchmark.lock"}) {
            int fd=open(path,O_CREAT|O_RDWR,0600);if(fd<0||flock(fd,LOCK_EX|LOCK_NB))throw std::runtime_error(std::string("benchmark lock unavailable: ")+path);
        }
        size_t k=1<<20;int it=31,id=-1;uint64_t seed=20260923;bool test=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto val=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--case")id=std::stoi(val());else if(arg=="--iterations")it=std::stoi(val());else if(arg=="--seed")seed=std::stoull(val());
            else if(arg=="--k")k=std::stoull(val());else if(arg=="--test")test=true;else throw std::runtime_error("unknown option");
        }
        if(test){certified_arithmetic_test();k=256;it=1;}
        if(k<8||k%8||k>(1u<<20)||it<1||id< -1||id>3)throw std::runtime_error("invalid options");
        if(id>=0)certified_dispatch(id,k,it,seed,test);else for(int j=0;j<4;++j)certified_dispatch(j,k,it,seed,test);
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
