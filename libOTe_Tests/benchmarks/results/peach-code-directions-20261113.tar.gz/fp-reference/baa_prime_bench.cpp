// Reuses the previous harness's canonical field additions, setup sampler,
// permutation sampler, timing, and process lock convention.
#pragma GCC diagnostic push
// The imported main is not called; renaming removes C++'s implicit main return.
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main addition_only_harness_main
#include "encoder_bench.cpp"
#undef main
#pragma GCC diagnostic pop
#include "fp128_mul.h"

struct PortableMul {
    static constexpr const char* name="pseudo_mersenne";
    static inline F mul(F a,F b) {return fp128::mul(a,b);}
    static F encode(F a) {return a;} static F decode(F a) {return a;}
};
struct BmiMul {
    static constexpr const char* name="bmi2";
    static inline F mul(F a,F b) {return fp128::mul_bmi2(a,b);}
    static F encode(F a) {return a;} static F decode(F a) {return a;}
};
struct MontgomeryMul {
    static constexpr const char* name="montgomery";
    static inline F mul(F a,F b) {return fp128::montgomery(a,b);}
    static F encode(F a) {return fp128::mul(a,159);}
    static F decode(F a) {return fp128::montgomery(a,1);}
};

template<int B,int M> inline void rs_forward(const F* __restrict in,F* __restrict out) {
    F differences[B],state[B];
    #pragma GCC unroll 8
    for(int j=0;j<B;++j) differences[j]=out[j]=in[j];
    // Triangular differences ending at the last systematic evaluation point.
    #pragma GCC unroll 8
    for(int level=1;level<B;++level) {
        #pragma GCC unroll 8
        for(int j=0;j<B-level;++j) differences[j]=fp128::sub(differences[j+1],differences[j]);
    }
    #pragma GCC unroll 8
    for(int j=0;j<B;++j) state[j]=differences[B-1-j];
    #pragma GCC unroll 16
    for(int i=B;i<M;++i) {
        #pragma GCC unroll 8
        for(int j=B-2;j>=0;--j) state[j]=add(state[j],state[j+1]);
        out[i]=state[0];
    }
}
template<int B,int M> inline void rs_transpose(const F* __restrict in,F* __restrict out) {
    // Reverse the extrapolation circuit, then apply the transposed binomial
    // transform and the alternating signs of the finite differences.
    F adj[B];
    #pragma GCC unroll 8
    for(int j=0;j<B;++j) adj[j]=in[M-1];
    #pragma GCC unroll 16
    for(int i=M-2;i>=B;--i) {
        adj[0]=add(adj[0],in[i]);
        #pragma GCC unroll 8
        for(int j=0;j<B-1;++j) adj[j+1]=add(adj[j+1],adj[j]);
    }
    #pragma GCC unroll 8
    for(int level=0;level<B-1;++level) {
        #pragma GCC unroll 8
        for(int j=B-2;j>=level;--j) adj[j]=add(adj[j],adj[j+1]);
    }
    #pragma GCC unroll 8
    for(int i=0;i<B;++i) {
        if((B-1-i)&1) out[i]=fp128::sub(in[i],adj[B-1-i]);
        else out[i]=add(in[i],adj[B-1-i]);
    }
}

template<int B,int M> std::array<F,B*(M-B)> rs_coefficients() {
    std::array<F,B*(M-B)> result;
    for(int t=B;t<M;++t) for(int j=0;j<B;++j) {
        F numerator=1,denominator=1;
        for(int h=0;h<B;++h) if(h!=j) {
            numerator=fp128::mul(numerator,F(t-h));
            denominator=fp128::mul(denominator,j>=h?F(j-h):P-F(h-j));
        }
        result[(t-B)*B+j]=fp128::mul(numerator,fp128::inverse(denominator));
    }
    return result;
}
template<class Kernel,int B,int M,bool Transpose> void rs_dense(const F* __restrict in,F* __restrict out,
                                          size_t k,const F* __restrict coeff) {
    for(size_t block=0;block<k/B;++block) {
        const F* x=in+block*(Transpose?M:B);F* y=out+block*(Transpose?B:M);
        if constexpr(Transpose) {
            #pragma GCC unroll 8
            for(int j=0;j<B;++j) {
                F total=x[j];
                #pragma GCC unroll 16
                for(int t=B;t<M;++t) total=add(total,Kernel::mul(x[t],coeff[(t-B)*B+j]));
                y[j]=total;
            }
        } else {
            #pragma GCC unroll 8
            for(int j=0;j<B;++j) y[j]=x[j];
            #pragma GCC unroll 16
            for(int t=B;t<M;++t) {
                F total=Kernel::mul(x[0],coeff[(t-B)*B]);
                #pragma GCC unroll 8
                for(int j=1;j<B;++j) total=add(total,Kernel::mul(x[j],coeff[(t-B)*B+j]));
                y[t]=total;
            }
        }
    }
}
template<int B,int M,bool Transpose> void rs_fast(const F* __restrict in,F* __restrict out,size_t k) {
    for(size_t block=0;block<k/B;++block) {
        if constexpr(Transpose) rs_transpose<B,M>(in+block*M,out+block*B);
        else rs_forward<B,M>(in+block*B,out+block*M);
    }
}
template<int R,bool Transpose> void repeat(const F* __restrict in,F* __restrict out,size_t k) {
    for(size_t i=0;i<k;++i) {
        if constexpr(Transpose) {
            F total=in[R*i];
            #pragma GCC unroll 8
            for(int j=1;j<R;++j) total=add(total,in[R*i+j]);
            out[i]=total;
        } else {
            #pragma GCC unroll 8
            for(int j=0;j<R;++j) out[R*i+j]=in[i];
        }
    }
}

template<class Kernel,bool Transpose,int PF> void weighted_stage(const F* __restrict src,F* __restrict dst,
               const uint32_t* __restrict perm,const F* __restrict weights,size_t n) {
    // Four independent products per batch; the scan recurrence only connects
    // additions. No function pointers, heap buffers, or per-symbol dispatch.
    if constexpr(!Transpose) {
        F total=0;
        for(size_t i=0;i<n;i+=4) {
            if constexpr(PF) {
                __builtin_prefetch(src+perm[i+PF],0,1);__builtin_prefetch(src+perm[i+PF+1],0,1);
                __builtin_prefetch(src+perm[i+PF+2],0,1);__builtin_prefetch(src+perm[i+PF+3],0,1);
            }
            F x0=Kernel::mul(src[perm[i]],weights[i]);
            F x1=Kernel::mul(src[perm[i+1]],weights[i+1]);
            F x2=Kernel::mul(src[perm[i+2]],weights[i+2]);
            F x3=Kernel::mul(src[perm[i+3]],weights[i+3]);
            dst[i]=total=add(total,x0);dst[i+1]=total=add(total,x1);
            dst[i+2]=total=add(total,x2);dst[i+3]=total=add(total,x3);
        }
    } else {
        F total=0;
        for(size_t end=n;end;end-=4) {
            const size_t i=end-4;
            if constexpr(PF) if(i>=PF) {
                __builtin_prefetch(dst+perm[i-PF],1,1);__builtin_prefetch(dst+perm[i-PF+1],1,1);
                __builtin_prefetch(dst+perm[i-PF+2],1,1);__builtin_prefetch(dst+perm[i-PF+3],1,1);
            }
            F x3=add(total,src[i+3]),x2=add(x3,src[i+2]);
            F x1=add(x2,src[i+1]),x0=add(x1,src[i]);total=x0;
            dst[perm[i+3]]=Kernel::mul(x3,weights[i+3]);dst[perm[i+2]]=Kernel::mul(x2,weights[i+2]);
            dst[perm[i+1]]=Kernel::mul(x1,weights[i+1]);dst[perm[i]]=Kernel::mul(x0,weights[i]);
        }
    }
}

struct Stage {std::vector<uint32_t> p;std::vector<F> w;};
template<class Kernel> std::vector<Stage> setup_stages(size_t n,int count,uint64_t seed) {
    Rng rng{seed^0x365987abcd123456ULL};std::vector<Stage> stages;
    for(int i=0;i<count;++i) {
        Stage s;s.p=permutation(n,rng);s.w.resize(n);
        for(F& x:s.w) {F v;do {v=rng.field();}while(!v);x=Kernel::encode(v);}
        stages.push_back(std::move(s));
    }
    return stages;
}

template<class Kernel,int B,int M,int T,bool Transpose> void reference_encoder(const std::vector<F>& input,
              std::vector<F>& output,const std::vector<Stage>& stages,size_t k) {
    const size_t n=k/B*M;std::vector<F> a(n),b(n);
    std::vector<F> canonical(input.size());for(size_t i=0;i<input.size();++i) canonical[i]=Kernel::decode(input[i]);
    auto local=[&](const F* x,F* y) {
        if constexpr(B==1) repeat<M,Transpose>(x,y,k);
        else {auto c=rs_coefficients<B,M>();rs_dense<PortableMul,B,M,Transpose>(x,y,k,c.data());}
    };
    if constexpr(!Transpose) local(canonical.data(),a.data());else a=canonical;
    for(int pass=0;pass<T;++pass) {
        int stage=Transpose?T-1-pass:pass;const auto& s=stages[stage];
        F sum=0;
        if constexpr(Transpose) {
            for(size_t i=n;i--;) {
                sum=ref_add(sum,a[i]);b[s.p[i]]=fp128::mul(sum,Kernel::decode(s.w[i]));
            }
        } else {
            for(size_t i=0;i<n;++i) b[i]=sum=ref_add(sum,fp128::mul(a[s.p[i]],Kernel::decode(s.w[i])));
        }
        a.swap(b);
    }
    if constexpr(Transpose) {output.resize(k);local(a.data(),output.data());}else output=std::move(a);
}
uint64_t digest_field(const F* v,size_t n) {
    uint64_t h=0x153728496abcdef0ULL;
    for(size_t i=0;i<n;++i) h=std::rotl(h,7)^uint64_t(v[i])^uint64_t(v[i]>>64);
    sink=h;return h;
}

template<class Kernel,int B,int M,int T,bool Transpose,int PF> void encoder_case(const char* name,size_t k,
                                      int iterations,uint64_t seed,bool dense,bool check) {
    size_t n=k/B*M;auto start=Clock::now();Rng rng{seed};
    std::vector<F> input(Transpose?n:k),a(n),b(n);
    for(F& x:input) x=Kernel::encode(rng.field());
    auto stages=setup_stages<Kernel>(n,T,seed);
    std::array<F,B*(M-B)> coeff={};
    if constexpr(B>1) {coeff=rs_coefficients<B,M>();for(F& c:coeff)c=Kernel::encode(c);}
    double setup_ms=ms(start,Clock::now());
    auto local=[&](const F* x,F* y) {
        if constexpr(B==1) repeat<M,Transpose>(x,y,k);
        else if(dense) rs_dense<Kernel,B,M,Transpose>(x,y,k,coeff.data());
        else rs_fast<B,M,Transpose>(x,y,k);
    };
    std::vector<double> totals,locals;std::array<std::vector<double>,T> pass_times;
    F* final=nullptr;uint64_t hash=0;
    for(int run=-2;run<iterations;++run) {
        input[0]=add(input[0],Kernel::encode(1));auto begin=Clock::now();double local_ms;
        const F* current;
        if constexpr(Transpose) current=input.data();
        else {local(input.data(),a.data());current=a.data();}
        auto mark=Clock::now();local_ms=ms(begin,mark);
        for(int pass=0;pass<T;++pass) {
            int stage=Transpose?T-1-pass:pass;
            F* dst=current==a.data()?b.data():a.data();
            weighted_stage<Kernel,Transpose,PF>(current,dst,stages[stage].p.data(),stages[stage].w.data(),n);
            auto now=Clock::now();if(run>=0) pass_times[pass].push_back(ms(mark,now));mark=now;
            current=dst;
        }
        if constexpr(Transpose) {final=current==a.data()?b.data():a.data();local(current,final);local_ms=ms(mark,Clock::now());}
        else final=const_cast<F*>(current);
        auto end=Clock::now();if(run>=0) {totals.push_back(ms(begin,end));locals.push_back(local_ms);}
        hash=digest_field(final,Transpose?k:n);
    }
    if(check) {
        std::vector<F> expected;reference_encoder<Kernel,B,M,T,Transpose>(input,expected,stages,k);
        for(size_t i=0;i<expected.size();++i) if(expected[i]!=Kernel::decode(final[i]))
            throw std::runtime_error(std::string("full encoder mismatch: ")+name);
    }
    size_t payload=(input.capacity()+a.capacity()+b.capacity())*sizeof(F);
    for(const auto& s:stages) payload+=s.p.capacity()*4+s.w.capacity()*16;
    std::cout<<std::fixed<<std::setprecision(6)<<"{\"case\":\""<<name<<"\",\"kernel\":\""<<Kernel::name
      <<"\",\"direction\":\""<<(Transpose?"transpose":"forward")<<"\",\"local\":\""<<(dense?"dense":"finite_difference")
      <<"\",\"k\":"<<k<<",\"n\":"<<n<<",\"stages\":"<<T<<",\"prefetch\":"<<PF
      <<",\"iterations\":"<<iterations<<",\"seed\":"<<seed<<",\"validated\":"<<(check?"true":"false")
      <<",\"setup_ms\":"<<setup_ms<<",\"resident_payload_bytes\":"<<payload<<",\"checksum\":"<<hash;
    print_stat("total_ms",totals);print_stat("local_ms",locals);
    for(int pass=0;pass<T;++pass) print_stat(("stage"+std::to_string(pass)+"_ms").c_str(),pass_times[pass]);
    std::cout<<"}\n"<<std::flush;
}

template<class Kernel,int Chains> __attribute__((noinline)) uint64_t multiply_loop(size_t count,uint64_t seed) {
    Rng rng{seed};F accum[Chains],factor[Chains];
    for(int i=0;i<Chains;++i) {accum[i]=Kernel::encode(rng.field());factor[i]=Kernel::encode(rng.field());}
    for(size_t i=0;i<count;++i) {
        #pragma GCC unroll 8
        for(int j=0;j<Chains;++j) accum[j]=Kernel::mul(accum[j],factor[j]);
    }
    return digest_field(accum,Chains);
}
template<class Kernel,int Chains> void kernel_bench() {
    constexpr size_t products=1<<22;std::vector<double> times;
    for(int run=-2;run<9;++run) {
        auto start=Clock::now();sink=multiply_loop<Kernel,Chains>(products/Chains,123+run);
        double time=ms(start,Clock::now())*1e6/products;if(run>=0)times.push_back(time);
    }
    std::cout<<"{\"kernel\":\""<<Kernel::name<<"\",\"independent_chains\":"<<Chains;
    print_stat("ns_per_multiply",times);std::cout<<"}\n"<<std::flush;
}
void arithmetic_tests() {
    using boost::multiprecision::cpp_int;
    auto big=[](F a){return (cpp_int(uint64_t(a>>64))<<64)+uint64_t(a);};
    auto narrow=[](cpp_int a){return (F((a>>64).convert_to<uint64_t>())<<64)|a.convert_to<uint64_t>();};
    auto check=[&](F a,F b) {
        F expected=narrow(big(a)*big(b)%big(P));
        if(fp128::mul(a,b)!=expected||fp128::mul_bmi2(a,b)!=expected)throw std::runtime_error("multiply oracle mismatch");
        auto wide=fp128::product(a,b);if((big(wide.high)<<128)+big(wide.low)!=big(a)*big(b))throw std::runtime_error("wide product mismatch");
        if(fp128::sub(a,b)!=narrow((big(a)+big(P)-big(b))%big(P)))throw std::runtime_error("subtraction mismatch");
        F ma=MontgomeryMul::encode(a),mb=MontgomeryMul::encode(b);
        if(MontgomeryMul::decode(MontgomeryMul::mul(ma,mb))!=expected)throw std::runtime_error("Montgomery oracle mismatch");
    };
    const F edges[]={0,1,2,158,159,160,(F(1)<<64)-1,F(1)<<64,(F(1)<<127)-1,F(1)<<127,P-160,P-159,P-2,P-1};
    for(F a:edges)for(F b:edges)check(a,b);
    Rng rng{20260918};for(int i=0;i<1000000;++i)check(rng.field(),rng.field());
    for(int i=0;i<64;++i) {F a=rng.field();if(fp128::mul(a,fp128::inverse(a))!=1)throw std::runtime_error("inverse mismatch");}
    std::cerr<<"One million prime multiplication/subtraction oracle tests passed for all kernels.\n";
}
template<int B,int M> void local_tests() {
    auto c=rs_coefficients<B,M>();
    for(int i=0;i<B;++i) {F in[B]={},a[M],b[M];in[i]=1;rs_forward<B,M>(in,a);
        rs_dense<PortableMul,B,M,false>(in,b,B,c.data());if(!std::equal(a,a+M,b))throw std::runtime_error("RS forward basis mismatch");}
    for(int i=0;i<M;++i) {F in[M]={},a[B],b[B];in[i]=1;rs_transpose<B,M>(in,a);
        rs_dense<PortableMul,B,M,true>(in,b,B,c.data());if(!std::equal(a,a+B,b))throw std::runtime_error("RS transpose basis mismatch");}
    auto stages=setup_stages<PortableMul>(M,2,17);Rng rng{18};
    std::vector<F> x(B),z(M),y,t;for(auto& a:x)a=rng.field();for(auto& a:z)a=rng.field();
    reference_encoder<PortableMul,B,M,2,false>(x,y,stages,B);
    reference_encoder<PortableMul,B,M,2,true>(z,t,stages,B);
    F a=0,b=0;for(int i=0;i<M;++i)a=add(a,fp128::mul(y[i],z[i]));for(int i=0;i<B;++i)b=add(b,fp128::mul(x[i],t[i]));
    if(a!=b)throw std::runtime_error("encoder adjoint identity mismatch");
}
template<class Kernel,bool Transpose,int PF> void dispatch_baa(const std::string& name,size_t k,int it,uint64_t seed,bool dense,bool check) {
    if(name=="rs16_8") encoder_case<Kernel,8,16,2,Transpose,PF>(name.c_str(),k,it,seed,dense,check);
    else if(name=="rs16_4") encoder_case<Kernel,4,16,2,Transpose,PF>(name.c_str(),k,it,seed,dense,check);
    else if(name=="raa2_2") encoder_case<Kernel,1,2,2,Transpose,PF>(name.c_str(),k,it,seed,dense,check);
    else if(name=="raa2_3") encoder_case<Kernel,1,2,3,Transpose,PF>(name.c_str(),k,it,seed,dense,check);
    else if(name=="raa3_2") encoder_case<Kernel,1,3,2,Transpose,PF>(name.c_str(),k,it,seed,dense,check);
    else throw std::runtime_error("unknown BAA case");
}
template<class Kernel> void run_case(const std::string& name,const std::string& direction,size_t k,int it,uint64_t seed,bool dense,bool check,int pf) {
    if(direction=="forward"||direction=="both") {
        if(pf)dispatch_baa<Kernel,false,32>(name,k,it,seed,dense,check);else dispatch_baa<Kernel,false,0>(name,k,it,seed,dense,check);
    }
    if(direction=="transpose"||direction=="both") {
        if(pf)dispatch_baa<Kernel,true,32>(name,k,it,seed,dense,check);else dispatch_baa<Kernel,true,0>(name,k,it,seed,dense,check);
    }
}
int main(int argc,char** argv) {
    try {
        int lock=open("/tmp/prindal-addition-encoder-benchmark.lock",O_CREAT|O_RDWR,0600);
        if(lock<0||flock(lock,LOCK_EX|LOCK_NB))throw std::runtime_error("benchmark lock unavailable");
        std::string mode="encoders",name="all",kernel="pseudo_mersenne",direction="both";
        size_t k=1<<20;int it=9,pf=32;uint64_t seed=20260918;bool dense=false,check=false,reverse=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];auto value=[&](){if(++i==argc)throw std::runtime_error("missing value");return std::string(argv[i]);};
            if(arg=="--mode")mode=value();else if(arg=="--case")name=value();else if(arg=="--kernel")kernel=value();
            else if(arg=="--direction")direction=value();else if(arg=="--k")k=std::stoull(value());else if(arg=="--iterations")it=std::stoi(value());
            else if(arg=="--seed")seed=std::stoull(value());else if(arg=="--prefetch")pf=std::stoi(value());
            else if(arg=="--dense")dense=true;else if(arg=="--check")check=true;else if(arg=="--reverse")reverse=true;
            else throw std::runtime_error("unknown option");
        }
        if(mode=="kernels") {
            kernel_bench<PortableMul,1>();kernel_bench<BmiMul,1>();kernel_bench<MontgomeryMul,1>();
            kernel_bench<PortableMul,8>();kernel_bench<BmiMul,8>();kernel_bench<MontgomeryMul,8>();return 0;
        }
        if(mode=="test") {arithmetic_tests();local_tests<8,16>();local_tests<4,16>();k=256;it=1;check=true;direction="both";}
        if((mode!="test"&&mode!="encoders")||k<16||k%16||k>UINT32_MAX/4||it<1||(pf!=0&&pf!=32)||
           (direction!="forward"&&direction!="transpose"&&direction!="both"))throw std::runtime_error("invalid benchmark options");
        std::vector<std::string> cases={"raa2_2","rs16_8","raa2_3","raa3_2","rs16_4"};
        if(name!="all")cases={name};
        if(reverse)std::reverse(cases.begin(),cases.end());
        for(const auto& c:cases) {
            if(kernel=="pseudo_mersenne")run_case<PortableMul>(c,direction,k,it,seed,dense,check,pf);
            else if(kernel=="bmi2")run_case<BmiMul>(c,direction,k,it,seed,dense,check,pf);
            else if(kernel=="montgomery")run_case<MontgomeryMul>(c,direction,k,it,seed,dense,check,pf);
            else throw std::runtime_error("unknown multiplication kernel");
        }
    }catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
