import pathlib,subprocess,fcntl
root=pathlib.Path(__file__).resolve().parent
header=root/'libOTe/Tools/BlkAccCode/SmallFieldBaaCode.h'
source=root/'libOTe_Tests/benchmarks/ChosenBaaDirections.cpp'
original=header.read_text();bench=source.read_text()
source.write_text(bench.replace('    run<ReedMullerBaaCode<>>("gf128_rm", n, seed, iterations);','').replace('    run<ChosenBaaCode<8>>("gf128_rs", n, seed, iterations);',''))
results=[]
try:
    for fold in ['shift','clmul']:
        for pf in [128,256,512]:
            s=original.replace('Transpose ? 64 : 256','Transpose ? 64 : '+str(pf))
            if fold=='clmul':s=s.replace('overflow ^\n                overflow.slli_epi64(1) ^ overflow.slli_epi64(2) ^ overflow.slli_epi64(7)','overflow.clmulepi64_si128<0x00>(block(0, 0x87))')
            header.write_text(s)
            subprocess.run(['python3',str(root/'directions.py'),'wide4','build'],check=True)
            output=subprocess.check_output(['python3',str(root/'directions.py'),'wide4','2097152','15','2'],text=True)
            line=fold+','+str(pf)+','+output.strip().splitlines()[-1]
            print(line,flush=True);results.append(line)
finally:
    header.write_text(original);source.write_text(bench)
    (root/'sweep-small.csv').write_text('\n'.join(results)+'\n')
