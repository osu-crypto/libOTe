import pathlib,tarfile,hashlib,json,subprocess
root=pathlib.Path(__file__).resolve().parent
files=list(root.glob('final-*.csv'))+[root/'final-summary.json',root/'initial-matrix-results.tar.gz']
files += list(root.glob('*.py')) + [root/'FpBaaDirections.cpp']
files += list((root/'libOTe').rglob('*.h')) + list((root/'libOTe_Tests').rglob('*.cpp'))
files += [p for p in (root/'fp-reference').iterdir() if p.suffix in ['.cpp','.h','.inc']]
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n');files += [root/'source-sha256.json']
machine=subprocess.check_output(['uname','-a'],text=True)+subprocess.check_output(['c++','--version'],text=True)
for path in ['/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor','/sys/devices/system/cpu/cpu2/cpufreq/scaling_cur_freq','/sys/devices/system/cpu/cpufreq/boost']:
    p=pathlib.Path(path)
    if p.exists():machine+=path+': '+p.read_text()
(root/'machine.txt').write_text(machine);files += [root/'machine.txt']
with tarfile.open(root/'code-directions-results.tar.gz','w:gz') as tar:
    for p in files:tar.add(p,arcname=p.relative_to(root))
