import pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
header=root/'libOTe/Tools/BlkAccCode/SmallFieldBaaCode.h'
original=header.read_text()
fwd='''                const auto a=(p[J]>>24)+1, b=(p[J+1]>>24)+1;
                const auto product=block(0,a).clmulepi64_si128<0x00>(block(0,b)).get<u32>(0);
                const auto offset=Arithmetic::madd(values[J],b,values[J+1]);
                out[J]=Arithmetic::madd(sum,a,values[J]);
                out[J+1]=sum=Arithmetic::madd(sum,product,offset);
                forwardBatch<J + 2>(values, out, p, sum);'''
dual='''                const auto a=coefficient, b=(p[pos]>>24)+1;
                const auto product=block(0,a).clmulepi64_si128<0x00>(block(0,b)).get<u32>(0);
                const auto offset=Arithmetic::madd(in[pos],b,in[pos-1]);
                out[p[pos]&indexMask]=Arithmetic::madd(sum,a,in[pos]);
                out[p[pos-1]&indexMask]=sum=Arithmetic::madd(sum,product,offset);
                coefficient=(p[pos-1]>>24)+1;
                transposeBatch<J + 2>(in, out, p, sum, coefficient);'''
s=original.replace('''                out[J] = sum = Arithmetic::madd(sum, (p[J] >> 24) + 1, values[J]);
                forwardBatch<J + 1>(values, out, p, sum);''',fwd)
s=s.replace('''                sum = Arithmetic::madd(sum, coefficient, in[pos]);
                coefficient = (p[pos] >> 24) + 1;
                out[p[pos] & indexMask] = sum;
                transposeBatch<J + 1>(in, out, p, sum, coefficient);''',dual)
assert s!=original
try:
    header.write_text(s)
    subprocess.run(['python3',str(root/'directions.py'),'wide4','build'],check=True)
    for seed in [1,2,3]:subprocess.run(['python3',str(root/'directions.py'),'wide4','2097152','15',str(seed)],check=True)
finally:header.write_text(original)
