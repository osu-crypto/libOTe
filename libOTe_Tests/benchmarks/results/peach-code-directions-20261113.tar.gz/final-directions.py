import pathlib,subprocess,json,csv,io,statistics,hashlib
root=pathlib.Path(__file__).resolve().parent
subprocess.run(['python3',str(root/'directions.py'),'wide4','build'],check=True)
rows=[]
for seed in range(1,7):
    cases=['gf','fp'] if seed%2 else ['fp','gf']
    for case in cases:
        cmd=(['python3',str(root/'directions.py'),'wide4','2097152','31',str(seed)] if case=='gf' else
             ['taskset','-c','2',str(root/'fp-directions'),'2097152','31',str(seed)])
        output=subprocess.check_output(cmd,text=True)
        (root/f'final-{case}-{seed}.csv').write_text(output)
        for row in csv.DictReader(io.StringIO(output)):
            rows.append(row)
            print(row['code'],seed,row['forward_ms'],row['transpose_ms'],flush=True)
summary={}
for code in sorted({r['code'] for r in rows}):
    select=[r for r in rows if r['code']==code]
    summary[code]={d:{'median':statistics.median(float(r[d]) for r in select),
                     'min':min(float(r[d]) for r in select),'max':max(float(r[d]) for r in select)}
                   for d in ['forward_ms','transpose_ms']}
(root/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
